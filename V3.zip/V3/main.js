import CanvasEditor from './js/canvas-editor.js';
import ComponentManager from './js/components.js';
import LayerManager from './js/layers.js';
import PropertyManager from './js/properties.js';
import NavigationManager from './js/navigation.js';

class SiliconPhotonicDesigner {
    constructor() {
        this.canvasEditor = null;
        this.componentManager = null;
        this.layerManager = null;
        this.propertyManager = null;
        this.navigationManager = null;
        
        this.currentTool = 'select';
        this.gridVisible = true;
        this.gridSize = 10;
        this.zoomLevel = 1.0;
        
        this.init();
    }

    async init() {
        try {
            // 初始化各个管理器
            await this.initializeManagers();
            
            // 设置事件监听器
            this.setupEventListeners();
            
            // 初始化UI状态
            this.initializeUI();
            
            console.log('Silicon Photonic Designer initialized successfully');
        } catch (error) {
            console.error('Failed to initialize Silicon Photonic Designer:', error);
        }
    }

    async initializeManagers() {
        // 初始化画布编辑器
        this.canvasEditor = new CanvasEditor('design-canvas');
        await this.canvasEditor.init();

        // 初始化组件管理器
        this.componentManager = new ComponentManager();
        this.componentManager.init();

        // 初始化图层管理器
        this.layerManager = new LayerManager();
        this.layerManager.init();

        // 初始化属性管理器
        this.propertyManager = new PropertyManager();
        this.propertyManager.init();

        // 初始化导航管理器
        this.navigationManager = new NavigationManager();
        this.navigationManager.init();

        // 设置管理器之间的联系
        this.setupManagerConnections();
    }

    setupManagerConnections() {
        // 画布编辑器事件
        this.canvasEditor.on('selection:changed', (selection) => {
            this.propertyManager.updateProperties(selection);
            this.updateStatusBar();
        });

        this.canvasEditor.on('object:modified', (object) => {
            this.propertyManager.updateProperties([object]);
        });

        this.canvasEditor.on('mouse:move', (e) => {
            const pointer = this.canvasEditor.getPointer(e.e);
            this.updateCursorPosition(pointer.x, pointer.y);
        });

        // 组件管理器事件
        this.componentManager.on('component:dragstart', (component) => {
            console.log('Component drag started:', component);
        });

        // 图层管理器事件
        this.layerManager.on('layer:changed', (layer) => {
            this.canvasEditor.setActiveLayer(layer);
        });

        this.layerManager.on('layer:visibility', (layer, visible) => {
            this.canvasEditor.setLayerVisibility(layer, visible);
        });

        // 属性管理器事件
        this.propertyManager.on('property:changed', (property, value) => {
            this.canvasEditor.updateSelectedObjects(property, value);
        });
        
        // 初始化组件搜索
        this.componentManager.initializeComponentSearch();
    }

    setupEventListeners() {
        // 顶部导航事件
        document.addEventListener('click', (e) => {
            if (e.target.matches('.nav-btn')) {
                this.handleNavClick(e.target);
            }
        });

        // 侧边栏标签切换
        document.addEventListener('click', (e) => {
            if (e.target.matches('.tab-btn') || e.target.closest('.tab-btn')) {
                this.handleSidebarTabClick(e.target.closest('.tab-btn'));
            }
        });

        // 工具栏事件
        document.addEventListener('click', (e) => {
            if (e.target.matches('.toolbar-btn') || e.target.closest('.toolbar-btn')) {
                this.handleToolbarClick(e.target.closest('.toolbar-btn'));
            }
        });

        // 缩放适应
        document.getElementById('zoom-fit').addEventListener('click', () => {
            this.canvasEditor.zoomToFit();
            this.updateZoomLevel();
        });

        // 键盘快捷键
        document.addEventListener('keydown', (e) => {
            this.handleKeyboardShortcuts(e);
        });

        // 模态框事件
        document.getElementById('modal-close').addEventListener('click', () => {
            this.closeModal();
        });

        document.getElementById('modal-overlay').addEventListener('click', (e) => {
            if (e.target === e.currentTarget) {
                this.closeModal();
            }
        });

        // 窗口调整大小
        window.addEventListener('resize', () => {
            this.canvasEditor.resizeCanvas();
        });
    }

    initializeUI() {
        // 设置初始工具
        this.setActiveTool('select');
        
        // 设置初始侧边栏
        this.setActiveSidebarPanel('components');
        
        // 初始化网格
        this.updateGridDisplay();
        
        // 更新状态栏
        this.updateStatusBar();
        
        // 设置初始缩放级别
        this.updateZoomLevel();
    }

    handleNavClick(button) {
        // 移除所有active类
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        
        // 添加active类到点击的按钮
        button.classList.add('active');
        
        const tab = button.dataset.tab;
        this.navigationManager.switchTab(tab);
    }

    handleSidebarTabClick(button) {
        // 移除所有active类
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        
        // 添加active类到点击的按钮
        button.classList.add('active');
        
        const panel = button.dataset.panel;
        this.setActiveSidebarPanel(panel);
    }

    setActiveSidebarPanel(panelName) {
        // 隐藏所有面板
        document.querySelectorAll('.sidebar-panel').forEach(panel => {
            panel.classList.remove('active');
        });
        
        // 显示选中的面板
        const panel = document.getElementById(`${panelName}-panel`);
        if (panel) {
            panel.classList.add('active');
        }
    }

    handleToolbarClick(button) {
        const toolId = button.id;
        
        if (toolId.includes('-tool')) {
            // 工具选择
            this.setActiveTool(toolId.replace('-tool', ''));
        } else if (toolId === 'zoom-in') {
            this.canvasEditor.zoomIn();
            this.updateZoomLevel();
        } else if (toolId === 'zoom-out') {
            this.canvasEditor.zoomOut();
            this.updateZoomLevel();
        } else if (toolId === 'undo') {
            this.canvasEditor.undo();
        } else if (toolId === 'redo') {
            this.canvasEditor.redo();
        } 
    }

    setActiveTool(toolName) {
        // 移除所有active类
        document.querySelectorAll('.toolbar-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        
        // 添加active类到当前工具
        const toolButton = document.getElementById(`${toolName}-tool`);
        if (toolButton) {
            toolButton.classList.add('active');
        }
        
        this.currentTool = toolName;
        this.canvasEditor.setTool(toolName);
    }

    toggleGrid() {
        this.gridVisible = !this.gridVisible;
        this.updateGridDisplay();
        this.canvasEditor.setGridVisible(this.gridVisible);
    }

    updateGridDisplay() {
        const container = document.querySelector('.canvas-container');
        if (this.gridVisible) {
            container.classList.add('show-grid');
        } else {
            container.classList.remove('show-grid');
        }
    }

    updateZoomLevel() {
        const zoom = this.canvasEditor.getZoom();
        this.zoomLevel = zoom;
        const percentage = Math.round(zoom * 100);
        document.querySelector('.zoom-level').textContent = `${percentage}%`;
    }

    updateCursorPosition(x, y) {
        // 转换为微米单位（假设1像素 = 0.1微米）
        const umX = (x * 0.1).toFixed(1);
        const umY = (y * 0.1).toFixed(1);
        document.getElementById('cursor-position').textContent = `${umX}, ${umY}`;
    }

    updateStatusBar() {
        const selectedObjects = this.canvasEditor.getSelectedObjects();
        document.getElementById('selected-count').textContent = selectedObjects.length;
        
        const gridSizeElement = document.getElementById('grid-size');
        gridSizeElement.textContent = `${this.gridSize} μm`;
    }

    handleKeyboardShortcuts(e) {
        if (e.target.matches('input') || e.target.matches('textarea')) {
            return; // 忽略输入框中的快捷键
        }

        const ctrl = e.ctrlKey || e.metaKey;
        
        switch (e.key) {
            case 'Delete':
            case 'Backspace':
                this.canvasEditor.deleteSelected();
                break;
            case 'Escape':
                this.canvasEditor.clearSelection();
                this.closeModal();
                break;
            case 'z':
                if (ctrl && !e.shiftKey) {
                    e.preventDefault();
                    this.canvasEditor.undo();
                } else if (ctrl && e.shiftKey) {
                    e.preventDefault();
                    this.canvasEditor.redo();
                }
                break;
            case 'y':
                if (ctrl) {
                    e.preventDefault();
                    this.canvasEditor.redo();
                }
                break;
            case 'a':
                if (ctrl) {
                    e.preventDefault();
                    this.canvasEditor.selectAll();
                }
                break;
            case 'c':
                if (ctrl) {
                    e.preventDefault();
                    this.canvasEditor.copy();
                }
                break;
            case 'v':
                if (ctrl) {
                    e.preventDefault();
                    this.canvasEditor.paste();
                }
                break;
            case 'g':
                if (!ctrl) {
                    this.toggleGrid();
                }
                break;
            case '1':
                this.setActiveTool('select');
                break;
            case '2':
                this.setActiveTool('draw');
                break;
            case '3':
                this.setActiveTool('rectangle');
                break;
            case '4':
                this.setActiveTool('circle');
                break;
        }
    }

    showModal(title, content) {
        document.getElementById('modal-title').textContent = title;
        document.getElementById('modal-content').innerHTML = content;
        document.getElementById('modal-overlay').classList.add('active');
    }

    closeModal() {
        document.getElementById('modal-overlay').classList.remove('active');
    }

    // 公共API方法
    exportDesign() {
        return this.canvasEditor.exportToJSON();
    }

    importDesign(jsonData) {
        this.canvasEditor.loadFromJSON(jsonData);
    }

    saveProject() {
        const designData = this.exportDesign();
        // 这里可以实现保存到本地存储或服务器
        localStorage.setItem('silicon_photonic_design', JSON.stringify(designData));
        console.log('Project saved successfully');
    }

    loadProject() {
        const savedData = localStorage.getItem('silicon_photonic_design');
        if (savedData) {
            try {
                const designData = JSON.parse(savedData);
                this.importDesign(designData);
                console.log('Project loaded successfully');
            } catch (error) {
                console.error('Failed to load project:', error);
            }
        }
    }
}

// 初始化应用
document.addEventListener('DOMContentLoaded', () => {
    window.siliconDesigner = new SiliconPhotonicDesigner();
});

// 防止页面刷新时丢失数据
window.addEventListener('beforeunload', (e) => {
    if (window.siliconDesigner) {
        window.siliconDesigner.saveProject();
    }
});

// 导出主类
export default SiliconPhotonicDesigner;