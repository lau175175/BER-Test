class ComponentManager {
    constructor() {
        this.components = new Map();
        this.eventHandlers = {};
        this.isDragging = false;
    }

    init() {
        this.setupEventListeners();
        this.loadComponentLibrary();
    }

    setupEventListeners() {
        // 组件拖拽事件
        document.addEventListener('dragstart', (e) => {
            const componentItem = e.target.closest('.component-item');
            if (componentItem) {
                const componentType = componentItem.dataset.component;
                e.dataTransfer.setData('text/plain', componentType);
                e.dataTransfer.effectAllowed = 'copy';
                
                // 添加拖拽样式
                componentItem.classList.add('dragging');
                
                this.emit('component:dragstart', componentType);
            }
        });

        document.addEventListener('dragend', (e) => {
            const componentItem = e.target.closest('.component-item');
            if (componentItem) {
                componentItem.classList.remove('dragging');
            }
        });
    }

    loadComponentLibrary() {
        // 定义组件库数据
        const componentLibrary = {
            basic: [
                {
                    id: 'waveguide',
                    name: '波导',
                    category: 'basic',
                    description: '基础硅波导，用于光传输',
                    parameters: {
                        width: { default: 0.5, min: 0.1, max: 2.0, unit: 'μm' },
                        height: { default: 0.22, min: 0.1, max: 1.0, unit: 'μm' },
                        length: { default: 100, min: 1, max: 10000, unit: 'μm' }
                    },
                    ports: [
                        { name: 'input', position: 'left', type: 'optical' },
                        { name: 'output', position: 'right', type: 'optical' }
                    ]
                },
                {
                    id: 'coupler',
                    name: '耦合器',
                    category: 'basic',
                    description: '方向耦合器，用于功率分配',
                    parameters: {
                        coupling_length: { default: 10, min: 1, max: 100, unit: 'μm' },
                        gap: { default: 0.2, min: 0.1, max: 1.0, unit: 'μm' },
                        coupling_ratio: { default: 0.5, min: 0.1, max: 0.9, unit: '' }
                    },
                    ports: [
                        { name: 'input1', position: 'left-top', type: 'optical' },
                        { name: 'input2', position: 'left-bottom', type: 'optical' },
                        { name: 'output1', position: 'right-top', type: 'optical' },
                        { name: 'output2', position: 'right-bottom', type: 'optical' }
                    ]
                },
                {
                    id: 'splitter',
                    name: '分路器',
                    category: 'basic',
                    description: '1x2功率分配器',
                    parameters: {
                        splitting_ratio: { default: 0.5, min: 0.1, max: 0.9, unit: '' },
                        taper_length: { default: 15, min: 5, max: 50, unit: 'μm' }
                    },
                    ports: [
                        { name: 'input', position: 'left', type: 'optical' },
                        { name: 'output1', position: 'right-top', type: 'optical' },
                        { name: 'output2', position: 'right-bottom', type: 'optical' }
                    ]
                },
                {
                    id: 'mzi',
                    name: 'MZI',
                    category: 'basic',
                    description: 'Mach-Zehnder干涉仪',
                    parameters: {
                        arm_length: { default: 100, min: 10, max: 1000, unit: 'μm' },
                        path_difference: { default: 0, min: -100, max: 100, unit: 'μm' }
                    },
                    ports: [
                        { name: 'input', position: 'left', type: 'optical' },
                        { name: 'output', position: 'right', type: 'optical' }
                    ]
                }
            ],
            active: [
                {
                    id: 'laser',
                    name: '激光器',
                    category: 'active',
                    description: '分布式反馈激光器',
                    parameters: {
                        wavelength: { default: 1550, min: 1260, max: 1625, unit: 'nm' },
                        power: { default: 10, min: 0.1, max: 100, unit: 'mW' },
                        linewidth: { default: 1, min: 0.1, max: 10, unit: 'MHz' }
                    },
                    ports: [
                        { name: 'output', position: 'right', type: 'optical' },
                        { name: 'cathode', position: 'top', type: 'electrical' },
                        { name: 'anode', position: 'bottom', type: 'electrical' }
                    ]
                },
                {
                    id: 'modulator',
                    name: '调制器',
                    category: 'active',
                    description: '电光调制器',
                    parameters: {
                        vpi: { default: 3, min: 1, max: 10, unit: 'V' },
                        bandwidth: { default: 30, min: 1, max: 100, unit: 'GHz' },
                        insertion_loss: { default: 3, min: 0.5, max: 10, unit: 'dB' }
                    },
                    ports: [
                        { name: 'input', position: 'left', type: 'optical' },
                        { name: 'output', position: 'right', type: 'optical' },
                        { name: 'rf_in', position: 'top', type: 'electrical' }
                    ]
                },
                {
                    id: 'detector',
                    name: '探测器',
                    category: 'active',
                    description: '光电探测器',
                    parameters: {
                        responsivity: { default: 1.0, min: 0.1, max: 2.0, unit: 'A/W' },
                        dark_current: { default: 10, min: 1, max: 1000, unit: 'nA' },
                        bandwidth: { default: 10, min: 0.1, max: 100, unit: 'GHz' }
                    },
                    ports: [
                        { name: 'input', position: 'left', type: 'optical' },
                        { name: 'output', position: 'right', type: 'optical' },
                        { name: 'rf_in', position: 'top', type: 'electrical' }
                    ]
                },
                {
                    id: 'phase_shifter',
                    name: '移相器',
                    category: 'active',
                    description: '热光移相器',
                    parameters: {
                        length: { default: 100, min: 10, max: 1000, unit: 'μm' },
                        power: { default: 10, min: 0.1, max: 100, unit: 'mW' },
                        efficiency: { default: 10, min: 1, max: 50, unit: 'mW/π' }
                    },
                    ports: [
                        { name: 'input', position: 'left', type: 'optical' },
                        { name: 'output', position: 'right', type: 'optical' },
                        { name: 'heater', position: 'top', type: 'electrical' }
                    ]
                }
            ]
        };

        // 存储组件定义
        Object.values(componentLibrary).forEach(category => {
            category.forEach(component => {
                this.components.set(component.id, component);
            });
        });

        console.log('Component library loaded:', this.components.size, 'components');
    }

    getComponent(id) {
        return this.components.get(id);
    }

    getComponentsByCategory(category) {
        return Array.from(this.components.values()).filter(comp => comp.category === category);
    }

    getAllComponents() {
        return Array.from(this.components.values());
    }

    createComponentInstance(type, position = { x: 0, y: 0 }) {
        const componentDef = this.getComponent(type);
        if (!componentDef) {
            console.warn('Unknown component type:', type);
            return null;
        }

        // 创建组件实例
        const instance = {
            id: this.generateId(),
            type: type,
            definition: componentDef,
            position: { ...position },
            parameters: this.getDefaultParameters(componentDef),
            rotation: 0,
            layer: 'si',
            connections: {},
            metadata: {
                created: new Date(),
                modified: new Date()
            }
        };

        return instance;
    }

    // 添加组件搜索功能
    initializeComponentSearch() {
        const searchInput = document.createElement('input');
        searchInput.type = 'text';
        searchInput.placeholder = '搜索组件...';
        searchInput.className = 'component-search';
        searchInput.style.cssText = `
            width: 100%;
            padding: 8px 12px;
            background: #333;
            border: 1px solid #555;
            border-radius: 4px;
            color: #e0e0e0;
            font-size: 13px;
            margin-bottom: 15px;
        `;
        
        const componentsPanel = document.getElementById('components-panel');
        const panelHeader = componentsPanel.querySelector('.panel-header');
        panelHeader.insertAdjacentElement('afterend', searchInput);
        
        searchInput.addEventListener('input', (e) => {
            this.filterComponents(e.target.value);
        });
    }

    filterComponents(searchTerm) {
        const componentItems = document.querySelectorAll('.component-item');
        const categories = document.querySelectorAll('.category');
        
        if (!searchTerm.trim()) {
            // 显示所有组件
            componentItems.forEach(item => item.style.display = 'flex');
            categories.forEach(category => category.style.display = 'block');
            return;
        }
        
        const term = searchTerm.toLowerCase();
        
        categories.forEach(category => {
            const categoryItems = category.querySelectorAll('.component-item');
            let hasVisibleItems = false;
            
            categoryItems.forEach(item => {
                const componentName = item.querySelector('span').textContent.toLowerCase();
                const componentType = item.dataset.component.toLowerCase();
                
                if (componentName.includes(term) || componentType.includes(term)) {
                    item.style.display = 'flex';
                    hasVisibleItems = true;
                } else {
                    item.style.display = 'none';
                }
            });
            
            category.style.display = hasVisibleItems ? 'block' : 'none';
        });
    }

    getDefaultParameters(componentDef) {
        const params = {};
        
        if (componentDef.parameters) {
            Object.entries(componentDef.parameters).forEach(([key, config]) => {
                params[key] = config.default;
            });
        }
        
        return params;
    }

    validateParameters(componentId, parameters) {
        const componentDef = this.getComponent(componentId);
        if (!componentDef || !componentDef.parameters) {
            return { valid: true, errors: [] };
        }

        const errors = [];
        
        Object.entries(parameters).forEach(([key, value]) => {
            const paramConfig = componentDef.parameters[key];
            if (!paramConfig) {
                errors.push(`Unknown parameter: ${key}`);
                return;
            }

            if (typeof value !== 'number') {
                errors.push(`Parameter ${key} must be a number`);
                return;
            }

            if (paramConfig.min !== undefined && value < paramConfig.min) {
                errors.push(`Parameter ${key} must be >= ${paramConfig.min}${paramConfig.unit || ''}`);
            }

            if (paramConfig.max !== undefined && value > paramConfig.max) {
                errors.push(`Parameter ${key} must be <= ${paramConfig.max}${paramConfig.unit || ''}`);
            }
        });

        return {
            valid: errors.length === 0,
            errors: errors
        };
    }

    generateId() {
        return 'comp_' + Math.random().toString(36).substr(2, 9);
    }

    // 组件搜索和过滤
    searchComponents(query) {
        if (!query) return this.getAllComponents();
        
        const lowercaseQuery = query.toLowerCase();
        
        return this.getAllComponents().filter(component => {
            return component.name.toLowerCase().includes(lowercaseQuery) ||
                   component.description.toLowerCase().includes(lowercaseQuery) ||
                   component.id.toLowerCase().includes(lowercaseQuery);
        });
    }

    filterComponentsByCategory(category) {
        if (!category) return this.getAllComponents();
        return this.getComponentsByCategory(category);
    }

    // 组件模板管理
    saveComponentAsTemplate(instance, templateName) {
        const template = {
            name: templateName,
            baseComponent: instance.type,
            parameters: { ...instance.parameters },
            metadata: {
                created: new Date(),
                author: 'user'
            }
        };

        // 保存到本地存储
        const templates = this.getComponentTemplates();
        templates[templateName] = template;
        localStorage.setItem('component_templates', JSON.stringify(templates));
        
        return template;
    }

    getComponentTemplates() {
        try {
            const stored = localStorage.getItem('component_templates');
            return stored ? JSON.parse(stored) : {};
        } catch (error) {
            console.error('Error loading component templates:', error);
            return {};
        }
    }

    createFromTemplate(templateName, position = { x: 0, y: 0 }) {
        const templates = this.getComponentTemplates();
        const template = templates[templateName];
        
        if (!template) {
            console.warn('Template not found:', templateName);
            return null;
        }

        const instance = this.createComponentInstance(template.baseComponent, position);
        if (instance) {
            instance.parameters = { ...template.parameters };
        }
        
        return instance;
    }

    // 事件系统
    on(event, handler) {
        if (!this.eventHandlers[event]) {
            this.eventHandlers[event] = [];
        }
        this.eventHandlers[event].push(handler);
    }

    emit(event, data) {
        if (this.eventHandlers[event]) {
            this.eventHandlers[event].forEach(handler => handler(data));
        }
    }
}

export default ComponentManager;