class NavigationManager {
    constructor() {
        this.currentTab = 'file';
        this.eventHandlers = {};
        this.tabContent = new Map();
        this.activeModal = null;
    }

    init() {
        this.setupTabContent();
        this.setupEventListeners();
        this.initializeTab('file');
    }

    setupTabContent() {
        // 定义每个标签页的内容和功能
        this.tabContent.set('file', {
            name: '文件',
            description: '文件操作和项目管理',
            actions: [
                { id: 'new-project', name: '新建项目', icon: 'fas fa-file', shortcut: 'Ctrl+N' },
                { id: 'open-project', name: '打开项目', icon: 'fas fa-folder-open', shortcut: 'Ctrl+O' },
                { id: 'save-project', name: '保存项目', icon: 'fas fa-save', shortcut: 'Ctrl+S' },
                { id: 'save-as', name: '另存为', icon: 'fas fa-save' },
                { type: 'separator' },
                { id: 'import-gds', name: '导入 GDS', icon: 'fas fa-file-import' },
                { id: 'export-gds', name: '导出 GDS', icon: 'fas fa-file-export' },
                { id: 'export-dxf', name: '导出 DXF', icon: 'fas fa-file-export' },
                { type: 'separator' },
                { id: 'project-settings', name: '项目设置', icon: 'fas fa-cog' },
                { id: 'recent-files', name: '最近文件', icon: 'fas fa-clock' }
            ]
        });

        this.tabContent.set('code', {
            name: '代码',
            description: '代码生成和脚本编辑',
            actions: [
                { id: 'generate-python', name: '生成 Python 代码', icon: 'fab fa-python' },
                { id: 'generate-spice', name: '生成 SPICE 网表', icon: 'fas fa-microchip' },
                { id: 'generate-verilog', name: '生成 Verilog-A', icon: 'fas fa-code' },
                { type: 'separator' },
                { id: 'run-script', name: '运行脚本', icon: 'fas fa-play', shortcut: 'F5' },
                { id: 'debug-script', name: '调试脚本', icon: 'fas fa-bug' },
                { type: 'separator' },
                { id: 'code-templates', name: '代码模板', icon: 'fas fa-file-code' },
                { id: 'macro-recorder', name: '宏录制器', icon: 'fas fa-record-vinyl' }
            ]
        });

        this.tabContent.set('simulation', {
            name: '仿真',
            description: '光学和电学仿真',
            actions: [
                { id: 'optical-simulation', name: '光学仿真', icon: 'fas fa-lightbulb' },
                { id: 'thermal-simulation', name: '热学仿真', icon: 'fas fa-thermometer-half' },
                { id: 'electrical-simulation', name: '电学仿真', icon: 'fas fa-bolt' },
                { type: 'separator' },
                { id: 'simulation-setup', name: '仿真设置', icon: 'fas fa-sliders-h' },
                { id: 'mesh-generation', name: '网格生成', icon: 'fas fa-th' },
                { id: 'boundary-conditions', name: '边界条件', icon: 'fas fa-border-style' },
                { type: 'separator' },
                { id: 'run-simulation', name: '运行仿真', icon: 'fas fa-play-circle', shortcut: 'Ctrl+R' },
                { id: 'view-results', name: '查看结果', icon: 'fas fa-chart-line' },
                { id: 'export-results', name: '导出结果', icon: 'fas fa-download' }
            ]
        });

        this.tabContent.set('agent', {
            name: 'AI助手',
            description: 'AI辅助设计和优化',
            actions: [
                { id: 'design-assistant', name: '设计助手', icon: 'fas fa-magic' },
                { id: 'parameter-optimization', name: '参数优化', icon: 'fas fa-chart-line' },
                { id: 'layout-generation', name: '版图生成', icon: 'fas fa-project-diagram' },
                { type: 'separator' },
                { id: 'design-rules-check', name: '设计规则检查', icon: 'fas fa-check-circle' },
                { id: 'performance-prediction', name: '性能预测', icon: 'fas fa-crystal-ball' },
                { id: 'manufacturing-analysis', name: '制造分析', icon: 'fas fa-industry' },
                { type: 'separator' },
                { id: 'ai-chat', name: 'AI对话', icon: 'fas fa-comments' },
                { id: 'knowledge-base', name: '知识库', icon: 'fas fa-book' }
            ]
        });
    }

    setupEventListeners() {
        // 监听导航按钮点击
        document.addEventListener('click', (e) => {
            if (e.target.matches('.nav-btn') || e.target.closest('.nav-btn')) {
                const button = e.target.closest('.nav-btn');
                const tab = button.dataset.tab;
                if (tab) {
                    this.switchTab(tab);
                }
            }
        });

        // 监听键盘快捷键
        document.addEventListener('keydown', (e) => {
            this.handleKeyboardShortcuts(e);
        });
    }

    switchTab(tabName) {
        if (this.currentTab === tabName) {
            // 如果已经是当前标签，显示/隐藏功能面板
            this.toggleTabPanel(tabName);
            return;
        }

        this.currentTab = tabName;
        this.updateTabDisplay();
        this.showTabContent(tabName);
        this.emit('tab:changed', tabName);
    }

    updateTabDisplay() {
        // 更新导航按钮的活动状态
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.classList.remove('active');
        });

        const activeBtn = document.querySelector(`[data-tab="${this.currentTab}"]`);
        if (activeBtn) {
            activeBtn.classList.add('active');
        }
    }

    showTabContent(tabName) {
        const content = this.tabContent.get(tabName);
        if (!content) return;

        // 创建并显示功能面板
        this.createTabPanel(content);
    }

    createTabPanel(content) {
        // 移除现有的功能面板
        const existingPanel = document.querySelector('.tab-panel');
        if (existingPanel) {
            existingPanel.remove();
        }

        // 创建新的功能面板
        const panel = document.createElement('div');
        panel.className = 'tab-panel';
        panel.innerHTML = this.generatePanelHTML(content);

        // 添加样式
        this.addTabPanelStyles();

        // 插入到适当位置
        const navbar = document.querySelector('.top-navbar');
        navbar.parentNode.insertBefore(panel, navbar.nextSibling);

        // 设置事件监听器
        this.setupPanelEventListeners(panel);

        // 动画显示
        requestAnimationFrame(() => {
            panel.classList.add('show');
        });
    }

    generatePanelHTML(content) {
        let html = `
            <div class="panel-header">
                <div class="panel-title">
                    <h3>${content.name}</h3>
                    <p>${content.description}</p>
                </div>
                <button class="panel-close">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="panel-content">
                <div class="action-grid">
        `;

        content.actions.forEach(action => {
            if (action.type === 'separator') {
                html += '<div class="action-separator"></div>';
            } else {
                html += `
                    <div class="action-item" data-action="${action.id}">
                        <div class="action-icon">
                            <i class="${action.icon}"></i>
                        </div>
                        <div class="action-info">
                            <span class="action-name">${action.name}</span>
                            ${action.shortcut ? `<span class="action-shortcut">${action.shortcut}</span>` : ''}
                        </div>
                    </div>
                `;
            }
        });

        html += `
                </div>
            </div>
        `;

        return html;
    }

    addTabPanelStyles() {
        if (document.querySelector('#tab-panel-styles')) return;

        const style = document.createElement('style');
        style.id = 'tab-panel-styles';
        style.textContent = `
            .tab-panel {
                position: absolute;
                top: 60px;
                left: 0;
                right: 0;
                background: #2a2a2a;
                border-bottom: 1px solid #404040;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
                z-index: 999;
                max-height: 0;
                overflow: hidden;
                transition: max-height 0.3s ease, opacity 0.3s ease;
                opacity: 0;
            }

            .tab-panel.show {
                max-height: 300px;
                opacity: 1;
            }

            .panel-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 20px;
                border-bottom: 1px solid #404040;
                background: #1e1e1e;
            }

            .panel-title h3 {
                font-size: 18px;
                color: #e0e0e0;
                margin: 0 0 4px 0;
            }

            .panel-title p {
                font-size: 13px;
                color: #b0b0b0;
                margin: 0;
            }

            .panel-close {
                width: 32px;
                height: 32px;
                background: transparent;
                border: 1px solid #404040;
                border-radius: 4px;
                color: #b0b0b0;
                cursor: pointer;
                transition: all 0.3s ease;
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .panel-close:hover {
                background: rgba(244, 67, 54, 0.1);
                color: #f44336;
                border-color: #f44336;
            }

            .panel-content {
                padding: 20px;
                max-height: 200px;
                overflow-y: auto;
            }

            .action-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 8px;
            }

            .action-item {
                display: flex;
                align-items: center;
                padding: 12px;
                background: #333;
                border: 1px solid #404040;
                border-radius: 6px;
                cursor: pointer;
                transition: all 0.3s ease;
            }

            .action-item:hover {
                background: #3a3a3a;
                border-color: #4fc3f7;
                transform: translateY(-1px);
            }

            .action-icon {
                width: 32px;
                height: 32px;
                background: rgba(79, 195, 247, 0.1);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-right: 12px;
                color: #4fc3f7;
            }

            .action-info {
                flex: 1;
            }

            .action-name {
                display: block;
                font-size: 14px;
                color: #e0e0e0;
                font-weight: 500;
            }

            .action-shortcut {
                font-size: 12px;
                color: #b0b0b0;
                margin-top: 2px;
                display: block;
            }

            .action-separator {
                grid-column: 1 / -1;
                height: 1px;
                background: #404040;
                margin: 8px 0;
            }

            @media (max-width: 768px) {
                .action-grid {
                    grid-template-columns: 1fr;
                }
                
                .panel-content {
                    padding: 15px;
                }
            }
        `;
        document.head.appendChild(style);
    }

    setupPanelEventListeners(panel) {
        // 关闭按钮
        panel.querySelector('.panel-close').addEventListener('click', () => {
            this.hideTabPanel();
        });

        // 功能项点击
        panel.addEventListener('click', (e) => {
            const actionItem = e.target.closest('.action-item');
            if (actionItem) {
                const actionId = actionItem.dataset.action;
                this.executeAction(actionId);
            }
        });

        // 点击外部关闭面板
        const closePanel = (e) => {
            if (!panel.contains(e.target) && !e.target.closest('.nav-btn')) {
                this.hideTabPanel();
                document.removeEventListener('click', closePanel);
            }
        };

        setTimeout(() => {
            document.addEventListener('click', closePanel);
        }, 100);
    }

    toggleTabPanel(tabName) {
        const existingPanel = document.querySelector('.tab-panel');
        if (existingPanel && existingPanel.classList.contains('show')) {
            this.hideTabPanel();
        } else {
            this.showTabContent(tabName);
        }
    }

    hideTabPanel() {
        const panel = document.querySelector('.tab-panel');
        if (panel) {
            panel.classList.remove('show');
            setTimeout(() => {
                panel.remove();
            }, 300);
        }
    }

    executeAction(actionId) {
        console.log('Executing action:', actionId);
        
        // 隐藏面板
        this.hideTabPanel();

        // 根据动作ID执行相应的功能
        switch (actionId) {
            case 'new-project':
                this.newProject();
                break;
            case 'open-project':
                this.openProject();
                break;
            case 'save-project':
                this.saveProject();
                break;
            case 'import-gds':
                this.importGDS();
                break;
            case 'export-gds':
                this.exportGDS();
                break;
            case 'generate-python':
                this.generatePythonCode();
                break;
            case 'run-simulation':
                this.runSimulation();
                break;
            case 'ai-chat':
                this.openAIChat();
                break;
            // ... 其他动作
            default:
                this.showComingSoon(actionId);
        }

        this.emit('action:executed', actionId);
    }

    // 具体功能实现
    newProject() {
        if (confirm('创建新项目将丢失当前未保存的工作，是否继续？')) {
            if (window.siliconDesigner) {
                window.siliconDesigner.canvasEditor.canvas.clear();
                console.log('New project created');
            }
        }
    }

    openProject() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json';
        input.onchange = (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    try {
                        const projectData = JSON.parse(e.target.result);
                        if (window.siliconDesigner) {
                            window.siliconDesigner.importDesign(projectData);
                        }
                        console.log('Project loaded successfully');
                    } catch (error) {
                        alert('无法加载项目文件：' + error.message);
                    }
                };
                reader.readAsText(file);
            }
        };
        input.click();
    }

    saveProject() {
        if (window.siliconDesigner) {
            const projectData = window.siliconDesigner.exportDesign();
            const blob = new Blob([JSON.stringify(projectData, null, 2)], {
                type: 'application/json'
            });
            
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'silicon_photonic_design.json';
            a.click();
            
            URL.revokeObjectURL(url);
            console.log('Project saved successfully');
        }
    }

    importGDS() {
        this.showComingSoon('GDS导入功能正在开发中');
    }

    exportGDS() {
        this.showComingSoon('GDS导出功能正在开发中');
    }

    generatePythonCode() {
        const pythonCode = this.generatePythonFromDesign();
        this.showCodeModal('Python代码', pythonCode, 'python');
    }

    generatePythonFromDesign() {
        // 简化的Python代码生成
        return `
import gdsfactory as gf
from gdsfactory import Component

# 自动生成的硅光版图Python代码
def create_design():
    c = Component("silicon_photonic_design")
    
    # 添加波导
    waveguide = c << gf.components.straight(length=100, width=0.5)
    
    # 添加其他组件...
    
    return c

if __name__ == "__main__":
    c = create_design()
    c.show()  # 在KLayout中显示
    c.write_gds("design.gds")  # 保存为GDS文件
        `.trim();
    }

    runSimulation() {
        this.showComingSoon('仿真功能正在开发中');
    }

    openAIChat() {
        this.showAIChatModal();
    }

    showComingSoon(message) {
        if (window.siliconDesigner && window.siliconDesigner.showModal) {
            window.siliconDesigner.showModal('即将推出', `
                <div style="text-align: center; padding: 20px;">
                    <i class="fas fa-rocket" style="font-size: 48px; color: #4fc3f7; margin-bottom: 16px;"></i>
                    <p style="font-size: 16px; color: #e0e0e0; margin-bottom: 8px;">敬请期待</p>
                    <p style="font-size: 14px; color: #b0b0b0;">${message}</p>
                </div>
            `);
        }
    }

    showCodeModal(title, code, language) {
        const content = `
            <div style="height: 400px; display: flex; flex-direction: column;">
                <div style="margin-bottom: 10px; display: flex; gap: 10px;">
                    <button id="copy-code" style="padding: 8px 16px; background: #4fc3f7; color: white; border: none; border-radius: 4px; cursor: pointer;">
                        <i class="fas fa-copy"></i> 复制代码
                    </button>
                    <button id="download-code" style="padding: 8px 16px; background: #4caf50; color: white; border: none; border-radius: 4px; cursor: pointer;">
                        <i class="fas fa-download"></i> 下载
                    </button>
                </div>
                <textarea style="flex: 1; background: #1e1e1e; color: #e0e0e0; border: 1px solid #404040; border-radius: 4px; padding: 16px; font-family: 'Courier New', monospace; font-size: 14px; line-height: 1.5; resize: none;" readonly>${code}</textarea>
            </div>
        `;

        if (window.siliconDesigner && window.siliconDesigner.showModal) {
            window.siliconDesigner.showModal(title, content);

            // 添加事件监听器
            document.getElementById('copy-code').addEventListener('click', () => {
                navigator.clipboard.writeText(code);
                alert('代码已复制到剪贴板');
            });

            document.getElementById('download-code').addEventListener('click', () => {
                const extension = language === 'python' ? 'py' : 'txt';
                const blob = new Blob([code], { type: 'text/plain' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `generated_code.${extension}`;
                a.click();
                URL.revokeObjectURL(url);
            });
        }
    }

    showAIChatModal() {
        const content = `
            <div style="height: 500px; display: flex; flex-direction: column;">
                <div style="flex: 1; background: #1e1e1e; border: 1px solid #404040; border-radius: 4px; padding: 16px; margin-bottom: 16px; overflow-y: auto;" id="chat-messages">
                    <div class="chat-message ai-message">
                        <div class="message-content">
                            <i class="fas fa-robot"></i>
                            <span>您好！我是您的硅光设计助手。我可以帮助您：</span>
                        </div>
                        <ul style="margin: 8px 0 0 24px; color: #b0b0b0;">
                            <li>优化设计参数</li>
                            <li>解答技术问题</li>
                            <li>生成设计代码</li>
                            <li>分析性能表现</li>
                        </ul>
                    </div>
                </div>
                <div style="display: flex; gap: 8px;">
                    <input type="text" id="chat-input" placeholder="输入您的问题..." style="flex: 1; padding: 12px; background: #333; border: 1px solid #555; border-radius: 4px; color: #e0e0e0;">
                    <button id="send-chat" style="padding: 12px 20px; background: #4fc3f7; color: white; border: none; border-radius: 4px; cursor: pointer;">
                        <i class="fas fa-paper-plane"></i>
                    </button>
                </div>
            </div>
        `;

        if (window.siliconDesigner && window.siliconDesigner.showModal) {
            window.siliconDesigner.showModal('AI助手', content);

            // 添加聊天功能
            this.setupChatInterface();
        }
    }

    setupChatInterface() {
        const chatInput = document.getElementById('chat-input');
        const sendButton = document.getElementById('send-chat');
        const messagesContainer = document.getElementById('chat-messages');

        const sendMessage = () => {
            const message = chatInput.value.trim();
            if (!message) return;

            // 添加用户消息
            this.addChatMessage('user', message);
            chatInput.value = '';

            // 模拟AI回复
            setTimeout(() => {
                const aiResponse = this.generateAIResponse(message);
                this.addChatMessage('ai', aiResponse);
            }, 1000);
        };

        sendButton.addEventListener('click', sendMessage);
        chatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });

        // 添加聊天样式
        if (!document.querySelector('#chat-styles')) {
            const style = document.createElement('style');
            style.id = 'chat-styles';
            style.textContent = `
                .chat-message {
                    margin-bottom: 16px;
                    padding: 12px;
                    border-radius: 8px;
                    max-width: 80%;
                }
                
                .chat-message.user-message {
                    background: #4fc3f7;
                    color: white;
                    margin-left: auto;
                    text-align: right;
                }
                
                .chat-message.ai-message {
                    background: #333;
                    color: #e0e0e0;
                    border: 1px solid #555;
                }
                
                .message-content {
                    display: flex;
                    align-items: flex-start;
                    gap: 8px;
                }
                
                .ai-message .message-content i {
                    color: #4fc3f7;
                    margin-top: 2px;
                }
            `;
            document.head.appendChild(style);
        }
    }

    addChatMessage(type, message) {
        const messagesContainer = document.getElementById('chat-messages');
        if (!messagesContainer) return;

        const messageDiv = document.createElement('div');
        messageDiv.className = `chat-message ${type}-message`;
        
        if (type === 'ai') {
            messageDiv.innerHTML = `
                <div class="message-content">
                    <i class="fas fa-robot"></i>
                    <span>${message}</span>
                </div>
            `;
        } else {
            messageDiv.innerHTML = `<span>${message}</span>`;
        }

        messagesContainer.appendChild(messageDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    generateAIResponse(userMessage) {
        // 简单的关键词匹配回复
        const lowerMessage = userMessage.toLowerCase();
        
        if (lowerMessage.includes('波导') || lowerMessage.includes('waveguide')) {
            return '波导是硅光芯片的基本传输元件。推荐使用宽度0.45-0.5μm的单模波导，可以在1550nm波长下实现良好的传输特性。需要注意的是，波导的弯曲半径应大于5μm以减少损耗。';
        } else if (lowerMessage.includes('耦合器') || lowerMessage.includes('coupler')) {
            return '方向耦合器的设计关键在于耦合长度和间距的优化。典型参数：间距200nm，耦合长度10-20μm。建议使用FDTD仿真来精确设计耦合比。';
        } else if (lowerMessage.includes('优化') || lowerMessage.includes('optimize')) {
            return '我可以帮您优化设计参数。请告诉我您想要优化的器件类型和目标性能指标，比如插入损耗、带宽、功耗等。';
        } else if (lowerMessage.includes('仿真') || lowerMessage.includes('simulation')) {
            return '硅光仿真通常包括：1) 光学仿真(FDTD/EME) 2) 热学仿真 3) 电学仿真。推荐使用Lumerical、COMSOL或开源的MEEP工具。';
        } else {
            return '感谢您的提问！我正在学习更多硅光知识来更好地帮助您。您可以询问关于波导、耦合器、调制器等器件的设计问题，或者寻求参数优化建议。';
        }
    }

    handleKeyboardShortcuts(e) {
        if (e.target.matches('input') || e.target.matches('textarea')) {
            return; // 忽略输入框中的快捷键
        }

        const ctrl = e.ctrlKey || e.metaKey;

        // 全局快捷键
        if (ctrl) {
            switch (e.key) {
                case 'n':
                    e.preventDefault();
                    this.executeAction('new-project');
                    break;
                case 'o':
                    e.preventDefault();
                    this.executeAction('open-project');
                    break;
                case 's':
                    e.preventDefault();
                    this.executeAction('save-project');
                    break;
                case 'r':
                    e.preventDefault();
                    this.executeAction('run-simulation');
                    break;
            }
        }

        // F键快捷键
        if (e.key === 'F5') {
            e.preventDefault();
            this.executeAction('run-script');
        }
    }

    initializeTab(tabName) {
        this.currentTab = tabName;
        this.updateTabDisplay();
    }

    // 事件系统
    on(event, handler) {
        if (!this.eventHandlers[event]) {
            this.eventHandlers[event] = [];
        }
        this.eventHandlers[event].push(handler);
    }

    emit(event, data) {
        if (this.eventHandlers[event]) {
            this.eventHandlers[event].forEach(handler => handler(data));
        }
    }
}

export default NavigationManager;