class PropertyManager {
    constructor() {
        this.selectedObjects = [];
        this.eventHandlers = {};
        this.propertyInputs = {};
        this.isUpdating = false;
    }

    init() {
        this.setupPropertyInputs();
        this.setupEventListeners();
        this.updatePropertyPanel();
    }

    setupPropertyInputs() {
        // 获取所有属性输入控件的引用
        this.propertyInputs = {
            x: document.getElementById('prop-x'),
            y: document.getElementById('prop-y'),
            width: document.getElementById('prop-width'),
            height: document.getElementById('prop-height'),
            rotation: document.getElementById('prop-rotation'),
            fill: document.getElementById('prop-fill'),
            stroke: document.getElementById('prop-stroke'),
            strokeWidth: document.getElementById('prop-stroke-width'),
            layer: document.getElementById('prop-layer')
        };
    }

    setupEventListeners() {
        // 为每个属性输入添加事件监听器
        Object.entries(this.propertyInputs).forEach(([property, input]) => {
            if (!input) return;

            const eventType = input.type === 'color' ? 'change' : 'input';
            
            input.addEventListener(eventType, (e) => {
                if (this.isUpdating) return; // 防止循环更新
                
                let value = e.target.value;
                
                // 数值类型转换
                if (input.type === 'number') {
                    value = parseFloat(value);
                    if (isNaN(value)) return;
                }
                
                this.updateObjectProperty(property, value);
            });

            // 对数值输入添加键盘快捷键支持
            if (input.type === 'number') {
                input.addEventListener('keydown', (e) => {
                    const step = parseFloat(input.step) || 1;
                    const shiftMultiplier = 10;
                    const altMultiplier = 0.1;
                    
                    let delta = 0;
                    
                    if (e.key === 'ArrowUp') {
                        delta = step;
                    } else if (e.key === 'ArrowDown') {
                        delta = -step;
                    } else {
                        return;
                    }
                    
                    if (e.shiftKey) {
                        delta *= shiftMultiplier;
                    } else if (e.altKey) {
                        delta *= altMultiplier;
                    }
                    
                    e.preventDefault();
                    
                    const currentValue = parseFloat(input.value) || 0;
                    const newValue = currentValue + delta;
                    
                    // 应用最小最大值限制
                    const min = input.min ? parseFloat(input.min) : -Infinity;
                    const max = input.max ? parseFloat(input.max) : Infinity;
                    const clampedValue = Math.max(min, Math.min(max, newValue));
                    
                    input.value = clampedValue.toFixed(input.step && input.step.includes('.') ? input.step.split('.')[1].length : 0);
                    input.dispatchEvent(new Event('input'));
                });
            }
        });

        // 监听属性面板展开/折叠
        document.addEventListener('click', (e) => {
            if (e.target.matches('.property-group h4')) {
                const group = e.target.closest('.property-group');
                group.classList.toggle('collapsed');
            }
        });

        // 添加属性组的预设切换功能
        this.setupPropertyPresets();
    }

    setupPropertyPresets() {
        // 为常用的属性组合创建预设
        const presets = {
            waveguide: {
                name: '波导',
                properties: {
                    fill: '#4FC3F7',
                    stroke: '#2196F3',
                    strokeWidth: 1,
                    layer: 'si'
                }
            },
            metal: {
                name: '金属',
                properties: {
                    fill: '#FF7043',
                    stroke: '#FF5722',
                    strokeWidth: 1,
                    layer: 'metal1'
                }
            },
            contact: {
                name: '接触',
                properties: {
                    fill: '#9C27B0',
                    stroke: '#7B1FA2',
                    strokeWidth: 1,
                    layer: 'contact'
                }
            }
        };

        // 创建预设选择器
        if (document.querySelector('.properties-panel')) {
            const presetGroup = document.createElement('div');
            presetGroup.className = 'property-group';
            presetGroup.innerHTML = `
                <h4>预设样式</h4>
                <div class="preset-buttons">
                    ${Object.entries(presets).map(([key, preset]) => 
                        `<button class="preset-btn" data-preset="${key}">${preset.name}</button>`
                    ).join('')}
                </div>
            `;

            document.querySelector('.properties-panel').insertBefore(
                presetGroup, 
                document.querySelector('.properties-panel').firstChild
            );

            // 添加预设按钮样式
            const style = document.createElement('style');
            style.textContent = `
                .preset-buttons {
                    display: flex;
                    gap: 5px;
                    flex-wrap: wrap;
                }
                .preset-btn {
                    padding: 6px 12px;
                    background: #333;
                    border: 1px solid #555;
                    border-radius: 4px;
                    color: #e0e0e0;
                    font-size: 12px;
                    cursor: pointer;
                    transition: all 0.3s ease;
                }
                .preset-btn:hover {
                    background: #4fc3f7;
                    border-color: #4fc3f7;
                }
            `;
            document.head.appendChild(style);

            // 预设按钮事件
            presetGroup.addEventListener('click', (e) => {
                if (e.target.matches('.preset-btn')) {
                    const presetKey = e.target.dataset.preset;
                    const preset = presets[presetKey];
                    if (preset) {
                        Object.entries(preset.properties).forEach(([property, value]) => {
                            this.updateObjectProperty(property, value);
                        });
                    }
                }
            });
        }
    }

    updateProperties(objects) {
        this.selectedObjects = objects || [];
        this.updatePropertyPanel();
    }

    updatePropertyPanel() {
        this.isUpdating = true;

        if (this.selectedObjects.length === 0) {
            // 没有选中对象，清空属性面板
            this.clearPropertyPanel();
        } else if (this.selectedObjects.length === 1) {
            // 单个对象，显示其属性
            this.showSingleObjectProperties(this.selectedObjects[0]);
        } else {
            // 多个对象，显示共同属性
            this.showMultipleObjectProperties(this.selectedObjects);
        }

        this.isUpdating = false;
    }

    clearPropertyPanel() {
        Object.values(this.propertyInputs).forEach(input => {
            if (input) {
                if (input.type === 'number') {
                    input.value = '';
                } else if (input.type === 'color') {
                    input.value = '#4FC3F7';
                } else if (input.tagName === 'SELECT') {
                    input.selectedIndex = 0;
                } else {
                    input.value = '';
                }
                input.disabled = true;
            }
        });

        // 更新属性面板标题
        this.updatePropertyPanelTitle('无选择');
    }

    showSingleObjectProperties(object) {
        // 启用所有输入控件
        Object.values(this.propertyInputs).forEach(input => {
            if (input) input.disabled = false;
        });

        // 更新属性值
        this.updatePropertyInput('x', this.getObjectProperty(object, 'left'));
        this.updatePropertyInput('y', this.getObjectProperty(object, 'top'));
        this.updatePropertyInput('width', this.getObjectProperty(object, 'width'));
        this.updatePropertyInput('height', this.getObjectProperty(object, 'height'));
        this.updatePropertyInput('rotation', this.getObjectProperty(object, 'angle') || 0);
        this.updatePropertyInput('fill', this.getObjectProperty(object, 'fill') || '#4FC3F7');
        this.updatePropertyInput('stroke', this.getObjectProperty(object, 'stroke') || '#2196F3');
        this.updatePropertyInput('strokeWidth', this.getObjectProperty(object, 'strokeWidth') || 1);
        
        // 图层信息（如果对象有图层数据）
        const layer = object.layer || 'si';
        this.updatePropertyInput('layer', layer);

        // 更新属性面板标题
        const objectType = this.getObjectDisplayName(object);
        this.updatePropertyPanelTitle(`${objectType} 属性`);

        // 显示对象特定的属性
        this.showObjectSpecificProperties(object);
    }

    showMultipleObjectProperties(objects) {
        // 启用所有输入控件
        Object.values(this.propertyInputs).forEach(input => {
            if (input) input.disabled = false;
        });

        // 计算共同属性值
        const commonProps = this.calculateCommonProperties(objects);
        
        Object.entries(commonProps).forEach(([property, value]) => {
            this.updatePropertyInput(property, value);
        });

        // 更新属性面板标题
        this.updatePropertyPanelTitle(`${objects.length} 个对象`);
    }

    calculateCommonProperties(objects) {
        const common = {};
        const properties = ['left', 'top', 'width', 'height', 'angle', 'fill', 'stroke', 'strokeWidth'];

        properties.forEach(prop => {
            const values = objects.map(obj => this.getObjectProperty(obj, prop))
                                  .filter(val => val !== null && val !== undefined);
            
            if (values.length > 0) {
                const firstValue = values[0];
                const allSame = values.every(val => val === firstValue);
                
                if (allSame) {
                    const mappedProp = this.mapPropertyName(prop);
                    common[mappedProp] = firstValue;
                }
            }
        });

        return common;
    }

    mapPropertyName(fabricProp) {
        const mapping = {
            'left': 'x',
            'top': 'y',
            'angle': 'rotation',
            'strokeWidth': 'strokeWidth'
        };
        
        return mapping[fabricProp] || fabricProp;
    }

    getObjectProperty(object, property) {
        if (!object) return null;

        // 处理Fabric.js对象的特殊属性访问
        if (property === 'width' || property === 'height') {
            // 对于某些对象类型，需要特殊处理尺寸
            if (object.type === 'circle') {
                return property === 'width' ? object.radius * 2 : object.radius * 2;
            } else if (object.type === 'line') {
                if (property === 'width') {
                    return Math.abs(object.x2 - object.x1);
                } else {
                    return Math.abs(object.y2 - object.y1);
                }
            }
        }

        return object[property];
    }

    updatePropertyInput(property, value) {
        const input = this.propertyInputs[property];
        if (!input || value === null || value === undefined) return;

        if (input.type === 'number') {
            // 数值输入，保留适当的小数位数
            const decimals = input.step && input.step.includes('.') ? 
                            input.step.split('.')[1].length : 1;
            input.value = Number(value).toFixed(decimals);
        } else if (input.type === 'color') {
            // 颜色输入，确保是有效的十六进制颜色
            input.value = this.normalizeColor(value);
        } else if (input.tagName === 'SELECT') {
            // 下拉选择
            input.value = value;
        } else {
            input.value = value;
        }
    }

    normalizeColor(color) {
        if (!color) return '#4FC3F7';
        
        // 如果已经是十六进制格式
        if (color.startsWith('#')) {
            return color.length === 7 ? color : '#4FC3F7';
        }
        
        // 处理RGB格式等其他颜色格式
        // 这里简化处理，实际可能需要更复杂的颜色转换
        return '#4FC3F7';
    }

    updateObjectProperty(property, value) {
        if (this.selectedObjects.length === 0) return;

        // 映射属性名到Fabric.js属性
        const fabricProperty = this.mapPropertyToFabric(property);
        
        this.selectedObjects.forEach(object => {
            this.setObjectProperty(object, fabricProperty, value);
        });

        // 触发属性更改事件
        this.emit('property:changed', property, value);
        
        // 更新显示（如果需要）
        if (window.siliconDesigner && window.siliconDesigner.canvasEditor) {
            window.siliconDesigner.canvasEditor.canvas.renderAll();
        }
    }

    mapPropertyToFabric(property) {
        const mapping = {
            'x': 'left',
            'y': 'top',
            'rotation': 'angle',
            'strokeWidth': 'strokeWidth'
        };
        
        return mapping[property] || property;
    }

    setObjectProperty(object, property, value) {
        if (!object) return;

        try {
            // 特殊处理某些属性
            if (property === 'width' || property === 'height') {
                if (object.type === 'circle') {
                    const radius = value / 2;
                    object.set('radius', radius);
                    return;
                } else if (object.type === 'line') {
                    if (property === 'width') {
                        const currentLength = Math.abs(object.x2 - object.x1);
                        const ratio = value / currentLength;
                        object.set('x2', object.x1 + (object.x2 - object.x1) * ratio);
                    } else {
                        const currentLength = Math.abs(object.y2 - object.y1);
                        const ratio = value / currentLength;
                        object.set('y2', object.y1 + (object.y2 - object.y1) * ratio);
                    }
                    return;
                }
            }

            // 设置标准属性
            object.set(property, value);
            
            // 对于尺寸变化，需要处理对象的缩放
            if (property === 'width' || property === 'height') {
                object.setCoords();
            }
            
            // 保存图层信息到对象的自定义属性
            if (property === 'layer') {
                object.layer = value;
            }
            
        } catch (error) {
            console.warn('Failed to set object property:', property, value, error);
        }
    }

    getObjectDisplayName(object) {
        if (!object) return 'Unknown';
        
        const typeNames = {
            'rect': '矩形',
            'circle': '圆形',
            'line': '线条',
            'path': '路径',
            'group': '组合',
            'text': '文本',
            'image': '图像'
        };
        
        return typeNames[object.type] || object.type;
    }

    updatePropertyPanelTitle(title) {
        const titleElement = document.querySelector('.right-sidebar .panel-header h3');
        if (titleElement) {
            titleElement.textContent = title;
        }
    }

    showObjectSpecificProperties(object) {
        // 根据对象类型显示特定的属性
        // 这里可以扩展来显示不同类型对象的专用属性
        
        if (object.type === 'circle') {
            this.showCircleProperties(object);
        } else if (object.type === 'line') {
            this.showLineProperties(object);
        } else if (object.componentType) {
            this.showComponentProperties(object);
        }
    }

    showCircleProperties(circle) {
        // 显示圆形特有的属性
        // 例如：半径、是否填充等
    }

    showLineProperties(line) {
        // 显示线条特有的属性
        // 例如：线条样式、端点样式等
    }

    showComponentProperties(component) {
        // 显示硅光组件特有的属性
        // 例如：工艺参数、端口信息等
        if (component.definition && component.definition.parameters) {
            this.showComponentParameterEditor(component);
        }
    }

    showComponentParameterEditor(component) {
        // 创建组件参数编辑器
        // 这里可以根据组件定义动态创建参数输入控件
        console.log('Show component parameters for:', component.componentType);
    }

    // 批量操作
    applyToSelected(properties) {
        Object.entries(properties).forEach(([property, value]) => {
            this.updateObjectProperty(property, value);
        });
    }

    // 属性历史记录
    savePropertyState() {
        if (this.selectedObjects.length === 0) return null;
        
        return this.selectedObjects.map(obj => ({
            id: obj.id,
            properties: {
                left: obj.left,
                top: obj.top,
                width: obj.width,
                height: obj.height,
                angle: obj.angle,
                fill: obj.fill,
                stroke: obj.stroke,
                strokeWidth: obj.strokeWidth
            }
        }));
    }

    restorePropertyState(state) {
        if (!state || !Array.isArray(state)) return;
        
        // 这里需要根据ID找到对象并恢复其属性
        // 实际实现需要与CanvasEditor协作
    }

    // 属性验证
    validateProperty(property, value, object) {
        switch (property) {
            case 'width':
            case 'height':
                return value > 0;
            case 'strokeWidth':
                return value >= 0;
            case 'angle':
                return value >= 0 && value <= 360;
            default:
                return true;
        }
    }

    // 单位转换
    convertUnit(value, fromUnit, toUnit) {
        // 实现微米、纳米等单位之间的转换
        const conversions = {
            'μm_to_nm': 1000,
            'nm_to_μm': 0.001,
            'μm_to_mm': 0.001,
            'mm_to_μm': 1000
        };
        
        const key = `${fromUnit}_to_${toUnit}`;
        return conversions[key] ? value * conversions[key] : value;
    }

    // 事件系统
    on(event, handler) {
        if (!this.eventHandlers[event]) {
            this.eventHandlers[event] = [];
        }
        this.eventHandlers[event].push(handler);
    }

    emit(event, data) {
        if (this.eventHandlers[event]) {
            this.eventHandlers[event].forEach(handler => handler(data));
        }
    }
}

export default PropertyManager;