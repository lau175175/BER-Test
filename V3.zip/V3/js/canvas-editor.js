// 使用CDN版本的fabric.js，在HTML中已引入

class CanvasEditor {
    constructor(canvasId) {
        this.canvasId = canvasId;
        this.canvas = null;
        this.gridSize = 20;
        this.gridVisible = true;
        this.tool = 'select';
        this.isDrawing = false;
        this.clipboard = null;
        this.history = [];
        this.historyIndex = -1;
        this.maxHistorySize = 50;
        
        this.eventHandlers = {};
        this.snapToGrid = true;
        this.showRulers = true;
    }

    async init() {
        // 初始化Fabric.js画布
        this.canvas = new fabric.Canvas(this.canvasId, {
            width: 800,
            height: 600,
            backgroundColor: '#1a1a1a',
            selection: true,
            preserveObjectStacking: true,
            enableRetinaScaling: true,
            imageSmoothingEnabled: false
        });

        // 设置画布属性
        this.setupCanvas();
        
        // 设置事件监听器
        this.setupEventListeners();
        
        // 绘制网格
        this.drawGrid();
        
        // 调整画布大小
        this.resizeCanvas();
        
        // 设置画布拖拽支持
        this.setupCanvasDragDrop();
        
        // 保存初始状态
        this.saveState();
    }

    setupCanvas() {
        // 设置画布样式
        this.canvas.setWidth(800);
        this.canvas.setHeight(600);
        
        // 设置对象默认属性
        fabric.Object.prototype.set({
            cornerColor: '#4fc3f7',
            cornerStyle: 'circle',
            cornerSize: 6,
            transparentCorners: false,
            borderColor: '#4fc3f7',
            borderDashArray: [3, 3],
            padding: 2
        });
        
        // 设置画布控制样式
        this.canvas.selectionColor = 'rgba(79, 195, 247, 0.1)';
        this.canvas.selectionBorderColor = '#4fc3f7';
        this.canvas.selectionLineWidth = 1;
    }

    setupCanvasDragDrop() {
        const canvasContainer = this.canvas.wrapperEl.parentNode;
        
        canvasContainer.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'copy';
        });
        
        canvasContainer.addEventListener('drop', (e) => {
            e.preventDefault();
            const componentType = e.dataTransfer.getData('text/plain');
            if (componentType) {
                const rect = canvasContainer.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                
                // 转换为画布坐标
                const pointer = this.canvas.getPointer(e);
                this.addComponent(componentType, pointer);
            }
        });
    }

    setupEventListeners() {
        // 鼠标事件
        this.canvas.on('mouse:down', (e) => this.handleMouseDown(e));
        this.canvas.on('mouse:move', (e) => this.handleMouseMove(e));
        this.canvas.on('mouse:up', (e) => this.handleMouseUp(e));
        
        // 选择事件
        this.canvas.on('selection:created', (e) => this.handleSelectionChanged(e));
        this.canvas.on('selection:updated', (e) => this.handleSelectionChanged(e));
        this.canvas.on('selection:cleared', () => this.handleSelectionChanged());
        
        // 对象修改事件
        this.canvas.on('object:modified', (e) => this.handleObjectModified(e));
        this.canvas.on('object:added', (e) => this.handleObjectAdded(e));
        this.canvas.on('object:removed', (e) => this.handleObjectRemoved(e));
        
        // 拖拽事件
        this.canvas.on('drop', (e) => this.handleDrop(e));
        this.canvas.on('dragover', (e) => this.handleDragOver(e));
        
        // 键盘事件
        document.addEventListener('keydown', (e) => this.handleKeyDown(e));
        
        // 鼠标滚轮缩放
        this.canvas.on('mouse:wheel', (opt) => {
            const delta = opt.e.deltaY;
            let zoom = this.canvas.getZoom();
            zoom *= 0.999 ** delta;
            if (zoom > 20) zoom = 20;
            if (zoom < 0.01) zoom = 0.01;
            this.canvas.zoomToPoint({ x: opt.e.offsetX, y: opt.e.offsetY }, zoom);
            opt.e.preventDefault();
            opt.e.stopPropagation();
        });
    }

    handleKeyDown(e) {
        if (e.target.matches('input') || e.target.matches('textarea')) return;
        
        const activeObject = this.canvas.getActiveObject();
        if (!activeObject) return;
        
        const step = e.shiftKey ? 10 : 1;
        
        switch (e.key) {
            case 'ArrowLeft':
                e.preventDefault();
                activeObject.set('left', activeObject.left - step);
                break;
            case 'ArrowRight':
                e.preventDefault();
                activeObject.set('left', activeObject.left + step);
                break;
            case 'ArrowUp':
                e.preventDefault();
                activeObject.set('top', activeObject.top - step);
                break;
            case 'ArrowDown':
                e.preventDefault();
                activeObject.set('top', activeObject.top + step);
                break;
        }
        
        if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.key)) {
            this.canvas.renderAll();
            this.emit('object:modified', activeObject);
        }
    }

    handleMouseDown(e) {
        if (!e.target) {
            this.canvas.discardActiveObject();
        }

        const pointer = this.canvas.getPointer(e.e);
        
        // 网格对齐
        if (this.snapToGrid) {
            pointer.x = Math.round(pointer.x / this.gridSize) * this.gridSize;
            pointer.y = Math.round(pointer.y / this.gridSize) * this.gridSize;
        }
        
        switch (this.tool) {
            case 'rectangle':
                this.startDrawingRectangle(pointer);
                break;
            case 'circle':
                this.startDrawingCircle(pointer);
                break;
            case 'draw':
                this.startDrawingPath(pointer);
                break;
        }
    }

    handleMouseMove(e) {
        const pointer = this.canvas.getPointer(e.e);
        this.emit('mouse:move', e);
        
        if (this.isDrawing) {
            switch (this.tool) {
                case 'rectangle':
                    this.updateRectangle(pointer);
                    break;
                case 'circle':
                    this.updateCircle(pointer);
                    break;
                case 'draw':
                    this.updateDrawingPath(pointer);
                    break;
            }
        }
    }

    handleMouseUp(e) {
        if (this.isDrawing) {
            this.finishDrawing();
            this.saveState();
        }
    }

    handleSelectionChanged(e) {
        const selectedObjects = this.canvas.getActiveObjects();
        this.emit('selection:changed', selectedObjects);
    }

    handleObjectModified(e) {
        this.emit('object:modified', e.target);
        this.saveState();
    }

    handleObjectAdded(e) {
        // 仅在非历史操作时保存状态
        if (!this.isHistoryOperation) {
            this.saveState();
        }
    }

    handleObjectRemoved(e) {
        // 仅在非历史操作时保存状态
        if (!this.isHistoryOperation) {
            this.saveState();
        }
    }

    startDrawingRectangle(pointer) {
        this.isDrawing = true;
        this.startPointer = pointer;
        
        this.drawingObject = new fabric.Rect({
            left: pointer.x,
            top: pointer.y,
            width: 0,
            height: 0,
            fill: 'rgba(79, 195, 247, 0.3)',
            stroke: '#4fc3f7',
            strokeWidth: 1,
            rx: 2,
            ry: 2
        });
        
        this.canvas.add(this.drawingObject);
    }

    updateRectangle(pointer) {
        if (!this.drawingObject) return;
        
        const width = Math.abs(pointer.x - this.startPointer.x);
        const height = Math.abs(pointer.y - this.startPointer.y);
        
        this.drawingObject.set({
            width: width,
            height: height,
            left: Math.min(this.startPointer.x, pointer.x),
            top: Math.min(this.startPointer.y, pointer.y)
        });
        
        this.canvas.renderAll();
    }

    startDrawingCircle(pointer) {
        this.isDrawing = true;
        this.startPointer = pointer;
        
        this.drawingObject = new fabric.Circle({
            left: pointer.x,
            top: pointer.y,
            radius: 0,
            fill: 'rgba(79, 195, 247, 0.3)',
            stroke: '#4fc3f7',
            strokeWidth: 1,
            originX: 'center',
            originY: 'center'
        });
        
        this.canvas.add(this.drawingObject);
    }

    updateCircle(pointer) {
        if (!this.drawingObject) return;
        
        const radius = Math.sqrt(
            Math.pow(pointer.x - this.startPointer.x, 2) + 
            Math.pow(pointer.y - this.startPointer.y, 2)
        ) / 2;
        
        this.drawingObject.set({
            radius: Math.max(1, radius)
        });
        
        this.canvas.renderAll();
    }

    startDrawingPath(pointer) {
        this.isDrawing = true;
        this.pathPoints = [pointer];
        
        this.drawingObject = new fabric.Path(`M ${pointer.x} ${pointer.y}`, {
            fill: '',
            stroke: '#4fc3f7',
            strokeWidth: 2,
            strokeLineCap: 'round',
            strokeLineJoin: 'round'
        });
        
        this.canvas.add(this.drawingObject);
    }

    updateDrawingPath(pointer) {
        if (!this.drawingObject || !this.pathPoints) return;
        
        this.pathPoints.push(pointer);
        
        let pathString = `M ${this.pathPoints[0].x} ${this.pathPoints[0].y}`;
        for (let i = 1; i < this.pathPoints.length; i++) {
            pathString += ` L ${this.pathPoints[i].x} ${this.pathPoints[i].y}`;
        }
        
        this.canvas.remove(this.drawingObject);
        this.drawingObject = new fabric.Path(pathString, {
            fill: '',
            stroke: '#4fc3f7',
            strokeWidth: 2
        });
        this.canvas.add(this.drawingObject);
        this.canvas.renderAll();
    }

    // 添加组件到画布
    addComponent(type, position) {
        const component = this.createComponent(type, position);
        if (component) {
            this.canvas.add(component);
            this.canvas.setActiveObject(component);
            this.canvas.renderAll();
            this.saveState();
            this.emit('component:added', { type, component });
        }
    }

    finishDrawing() {
        this.isDrawing = false;
        this.drawingObject = null;
        this.startPointer = null;
        this.pathPoints = null;
    }

    // 改进的网格绘制
    drawGrid() {
        if (!this.gridVisible) return;
        
        // 移除现有网格
        this.removeGrid();
        
        const canvasWidth = this.canvas.width;
        const canvasHeight = this.canvas.height;
        const zoom = this.canvas.getZoom();
        const vpt = this.canvas.viewportTransform;
        
        // 计算可见区域
        const left = -vpt[4] / zoom;
        const top = -vpt[5] / zoom;
        const right = left + canvasWidth / zoom;
        const bottom = top + canvasHeight / zoom;
        
        // 计算网格起始点
        const startX = Math.floor(left / this.gridSize) * this.gridSize;
        const startY = Math.floor(top / this.gridSize) * this.gridSize;
        
        const gridLines = [];
        
        // 绘制垂直线
        for (let x = startX; x <= right; x += this.gridSize) {
            const line = new fabric.Line([x, top, x, bottom], {
                stroke: 'rgba(79, 195, 247, 0.15)',
                strokeWidth: 0.5,
                selectable: false,
                evented: false,
                excludeFromExport: true
            });
            gridLines.push(line);
        }
        
        // 绘制水平线
        for (let y = startY; y <= bottom; y += this.gridSize) {
            const line = new fabric.Line([left, y, right, y], {
                stroke: 'rgba(79, 195, 247, 0.15)',
                strokeWidth: 0.5,
                selectable: false,
                evented: false,
                excludeFromExport: true
            });
            gridLines.push(line);
        }
        
        // 添加主网格线（每5个单位）
        for (let x = startX; x <= right; x += this.gridSize * 5) {
            const line = new fabric.Line([x, top, x, bottom], {
                stroke: 'rgba(79, 195, 247, 0.25)',
                strokeWidth: 1,
                selectable: false,
                evented: false,
                excludeFromExport: true
            });
            gridLines.push(line);
        }
        
        for (let y = startY; y <= bottom; y += this.gridSize * 5) {
            const line = new fabric.Line([left, y, right, y], {
                stroke: 'rgba(79, 195, 247, 0.25)',
                strokeWidth: 1,
                selectable: false,
                evented: false,
                excludeFromExport: true
            });
            gridLines.push(line);
        }
        
        // 创建网格组
        this.gridGroup = new fabric.Group(gridLines, {
            selectable: false,
            evented: false,
            excludeFromExport: true
        });
        
        this.canvas.add(this.gridGroup);
        this.canvas.sendToBack(this.gridGroup);
    }

    removeGrid() {
        if (this.gridGroup) {
            this.canvas.remove(this.gridGroup);
            this.gridGroup = null;
        }
    }

    drawGrid() {
        if (!this.gridVisible) return;
        
        const gridGroup = new fabric.Group([], {
            selectable: false,
            evented: false
        });
        
        const canvasWidth = this.canvas.width;
        const canvasHeight = this.canvas.height;
        
        // 绘制垂直线
        for (let x = 0; x <= canvasWidth; x += this.gridSize) {
            const line = new fabric.Line([x, 0, x, canvasHeight], {
                stroke: 'rgba(79, 195, 247, 0.1)',
                strokeWidth: 1,
                selectable: false,
                evented: false
            });
            gridGroup.addWithUpdate(line);
        }
        
        // 绘制水平线
        for (let y = 0; y <= canvasHeight; y += this.gridSize) {
            const line = new fabric.Line([0, y, canvasWidth, y], {
                stroke: 'rgba(79, 195, 247, 0.1)',
                strokeWidth: 1,
                selectable: false,
                evented: false
            });
            gridGroup.addWithUpdate(line);
        }
        
        this.canvas.add(gridGroup);
        this.canvas.sendToBack(gridGroup);
    }

    // 更新网格显示
    updateGrid() {
        if (this.gridVisible) {
            this.drawGrid();
        }
    }

    // 工具设置
    setTool(tool) {
        this.tool = tool;
        
        if (tool === 'select') {
            this.canvas.selection = true;
            this.canvas.defaultCursor = 'default';
        } else {
            this.canvas.selection = false;
            this.canvas.defaultCursor = 'crosshair';
        }
    }

    setGridVisible(visible) {
        this.gridVisible = visible;
        
        // 移除现有网格
        const objects = this.canvas.getObjects();
        objects.forEach(obj => {
            if (obj.type === 'group' && !obj.selectable) {
                this.canvas.remove(obj);
            }
        });
        
        // 重新绘制网格
        if (visible) {
            this.drawGrid();
        }
        
        this.canvas.renderAll();
    }

    setSnapToGrid(snap) {
        this.snapToGrid = snap;
    }

    setGridSize(size) {
        this.gridSize = size;
        if (this.gridVisible) {
            this.drawGrid();
        }
    }

    // 缩放功能
    zoomIn() {
        let zoom = this.canvas.getZoom();
        zoom = Math.min(zoom * 1.2, 5);
        this.canvas.setZoom(zoom);
        this.updateGrid();
    }

    zoomOut() {
        let zoom = this.canvas.getZoom();
        zoom = Math.max(zoom / 1.2, 0.1);
        this.canvas.setZoom(zoom);
        this.updateGrid();
    }

    zoomToFit() {
        const objects = this.canvas.getObjects().filter(obj => !obj.excludeFromExport);
        if (objects.length === 0) {
            this.canvas.setZoom(1);
            this.canvas.setViewportTransform([1, 0, 0, 1, 0, 0]);
            this.updateGrid();
            return;
        }
        
        const group = new fabric.Group(objects);
        const boundingRect = group.getBoundingRect();
        group.destroy();
        
        const canvasWidth = this.canvas.width;
        const canvasHeight = this.canvas.height;
        
        const scaleX = (canvasWidth * 0.8) / boundingRect.width;
        const scaleY = (canvasHeight * 0.8) / boundingRect.height;
        const zoom = Math.min(scaleX, scaleY);
        
        this.canvas.setZoom(zoom);
        
        const centerX = boundingRect.left + boundingRect.width / 2;
        const centerY = boundingRect.top + boundingRect.height / 2;
        
        this.canvas.absolutePan({
            x: canvasWidth / 2 - centerX * zoom,
            y: canvasHeight / 2 - centerY * zoom
        });
        
        this.updateGrid();
    }

    getZoom() {
        return this.canvas.getZoom();
    }

    // 选择操作
    getSelectedObjects() {
        return this.canvas.getActiveObjects();
    }

    clearSelection() {
        this.canvas.discardActiveObject();
        this.canvas.renderAll();
    }

    selectAll() {
        const allObjects = this.canvas.getObjects().filter(obj => obj.selectable !== false);
        if (allObjects.length > 1) {
            const selection = new fabric.ActiveSelection(allObjects, {
                canvas: this.canvas
            });
            this.canvas.setActiveObject(selection);
        } else if (allObjects.length === 1) {
            this.canvas.setActiveObject(allObjects[0]);
        }
        this.canvas.renderAll();
    }

    deleteSelected() {
        const activeObjects = this.canvas.getActiveObjects();
        if (activeObjects.length > 0) {
            this.canvas.remove(...activeObjects);
            this.canvas.discardActiveObject();
            this.canvas.renderAll();
            this.saveState();
        }
    }

    // 复制粘贴
    copy() {
        const activeObjects = this.canvas.getActiveObjects();
        if (activeObjects.length > 0) {
            this.clipboard = activeObjects.map(obj => obj.toObject());
        }
    }

    paste() {
        if (!this.clipboard) return;
        
        const objects = this.clipboard.map(objData => {
            return fabric.util.enlivenObjects([objData], (objects) => {
                objects.forEach(obj => {
                    obj.set({
                        left: obj.left + 20,
                        top: obj.top + 20
                    });
                    this.canvas.add(obj);
                });
                this.canvas.renderAll();
                this.saveState();
            });
        });
    }

    // 历史管理
    saveState() {
        const state = JSON.stringify(this.canvas.toJSON());
        
        // 移除当前索引之后的历史
        this.history = this.history.slice(0, this.historyIndex + 1);
        
        // 添加新状态
        this.history.push(state);
        this.historyIndex++;
        
        // 限制历史大小
        if (this.history.length > this.maxHistorySize) {
            this.history.shift();
            this.historyIndex--;
        }
    }

    undo() {
        if (this.historyIndex > 0) {
            this.historyIndex--;
            this.loadState(this.history[this.historyIndex]);
        }
    }

    redo() {
        if (this.historyIndex < this.history.length - 1) {
            this.historyIndex++;
            this.loadState(this.history[this.historyIndex]);
        }
    }

    loadState(state) {
        this.isHistoryOperation = true;
        
        this.canvas.loadFromJSON(state, () => {
            this.canvas.renderAll();
            this.isHistoryOperation = false;
        });
    }

    // 对象属性更新
    updateSelectedObjects(property, value) {
        const activeObjects = this.canvas.getActiveObjects();
        
        activeObjects.forEach(obj => {
            switch (property) {
                case 'x':
                    obj.set('left', parseFloat(value));
                    break;
                case 'y':
                    obj.set('top', parseFloat(value));
                    break;
                case 'width':
                    obj.set('width', parseFloat(value));
                    break;
                case 'height':
                    obj.set('height', parseFloat(value));
                    break;
                case 'rotation':
                    obj.set('angle', parseFloat(value));
                    break;
                case 'fill':
                    obj.set('fill', value);
                    break;
                case 'stroke':
                    obj.set('stroke', value);
                    break;
                case 'strokeWidth':
                    obj.set('strokeWidth', parseFloat(value));
                    break;
            }
        });
        
        this.canvas.renderAll();
        this.saveState();
    }

    // 组件拖拽
    startComponentDrag(componentType) {
        // 这个方法现在由addComponent处理
        console.log('Component drag started:', componentType);
    }

    createComponent(type, position = { x: 100, y: 100 }) {
        const baseProps = {
            left: position.x,
            top: position.y,
            fill: 'rgba(79, 195, 247, 0.8)',
            stroke: '#2196f3',
            strokeWidth: 1,
            componentType: type
        };

        switch (type) {
            case 'waveguide':
                return new fabric.Rect({
                    ...baseProps,
                    width: 100,
                    height: 4,
                    rx: 1,
                    ry: 1
                });
            
            case 'coupler':
                return new fabric.Group([
                    new fabric.Rect({ 
                        width: 40, height: 2, 
                        left: -20, top: -6,
                        fill: baseProps.fill, stroke: baseProps.stroke, strokeWidth: 0.5
                    }),
                    new fabric.Rect({ 
                        width: 40, height: 2, 
                        left: -20, top: 4,
                        fill: baseProps.fill, stroke: baseProps.stroke, strokeWidth: 0.5
                    }),
                    new fabric.Rect({ 
                        width: 40, height: 2, 
                        left: 20, top: -6,
                        fill: baseProps.fill, stroke: baseProps.stroke, strokeWidth: 0.5
                    }),
                    new fabric.Rect({ 
                        width: 40, height: 2, 
                        left: 20, top: 4,
                        fill: baseProps.fill, stroke: baseProps.stroke, strokeWidth: 0.5
                    })
                ], { ...baseProps, componentType: type });
                
            case 'splitter':
                return new fabric.Path('M -30 0 L 10 0 L 30 -15 M 10 0 L 30 15', {
                    ...baseProps,
                    fill: '',
                    strokeWidth: 2,
                    strokeLineCap: 'round'
                });
                
            case 'mzi':
                return new fabric.Group([
                    new fabric.Path('M -40 0 L -10 0 L -10 -15 L 40 -15 L 40 0 L 60 0', {
                        fill: '', stroke: baseProps.stroke, strokeWidth: 1.5
                    }),
                    new fabric.Path('M -10 0 L -10 15 L 40 15 L 40 0', {
                        fill: '', stroke: baseProps.stroke, strokeWidth: 1.5
                    })
                ], { ...baseProps, componentType: type });
                
            case 'laser':
                return new fabric.Group([
                    new fabric.Rect({ 
                        width: 30, height: 12, 
                        left: -15, top: -6,
                        fill: '#ff7043', stroke: '#ff5722', strokeWidth: 1
                    }),
                    new fabric.Polygon([
                        {x: 15, y: -6}, {x: 25, y: 0}, {x: 15, y: 6}
                    ], { fill: '#ff7043', stroke: '#ff5722', strokeWidth: 1 }),
                    new fabric.Line([25, 0, 40, 0], { 
                        stroke: baseProps.stroke, strokeWidth: 2 
                    })
                ], { ...baseProps, componentType: type });
                
            case 'modulator':
                return new fabric.Group([
                    new fabric.Rect({ 
                        width: 50, height: 4, 
                        left: -25, top: -2,
                        fill: baseProps.fill, stroke: baseProps.stroke, strokeWidth: 1
                    }),
                    new fabric.Rect({ 
                        width: 20, height: 16, 
                        left: -10, top: -8,
                        fill: 'transparent', stroke: '#FFB74D', strokeWidth: 1
                    })
                ], { ...baseProps, componentType: type });
                
            case 'detector':
                return new fabric.Group([
                    new fabric.Line([-20, 0, 0, 0], { 
                        stroke: baseProps.stroke, strokeWidth: 2 
                    }),
                    new fabric.Polygon([
                        {x: 0, y: -8}, {x: 0, y: 8}, {x: 15, y: 0}
                    ], { fill: '#4CAF50', stroke: '#388E3C', strokeWidth: 1 }),
                    new fabric.Rect({ 
                        width: 8, height: 4, 
                        left: 15, top: -2,
                        fill: '#4CAF50', stroke: '#388E3C', strokeWidth: 1
                    })
                ], { ...baseProps, componentType: type });
                
            default:
                return new fabric.Rect({
                    ...baseProps,
                    width: 20,
                    height: 20,
                    rx: 2,
                    ry: 2
                });
        }
    }

    // 画布操作
    resizeCanvas() {
        const container = document.querySelector('.canvas-container');
        if (container) {
            const rect = container.getBoundingClientRect();
            const newWidth = Math.max(400, rect.width);
            const newHeight = Math.max(300, rect.height);
            
            this.canvas.setDimensions({
                width: newWidth,
                height: newHeight
            });
            
            this.updateGrid();
        }
    }

    getPointer(e) {
        return this.canvas.getPointer(e);
    }

    // 导入导出
    exportToJSON() {
        return this.canvas.toJSON();
    }

    loadFromJSON(jsonData) {
        this.canvas.loadFromJSON(jsonData, () => {
            this.canvas.renderAll();
            this.updateGrid();
            this.saveState();
        });
    }

    // 导出为图片
    exportToPNG() {
        // 临时隐藏网格
        const gridVisible = this.gridVisible;
        if (gridVisible) {
            this.setGridVisible(false);
        }
        
        const dataURL = this.canvas.toDataURL({
            format: 'png',
            quality: 1,
            multiplier: 2
        });
        
        // 恢复网格
        if (gridVisible) {
            this.setGridVisible(true);
        }
        
        return dataURL;
    }

    // 导出为SVG
    exportToSVG() {
        const gridVisible = this.gridVisible;
        if (gridVisible) {
            this.setGridVisible(false);
        }
        
        const svg = this.canvas.toSVG();
        
        if (gridVisible) {
            this.setGridVisible(true);
        }
        
        return svg;
    }

    // 事件系统
    on(event, handler) {
        if (!this.eventHandlers[event]) {
            this.eventHandlers[event] = [];
        }
        this.eventHandlers[event].push(handler);
    }

    emit(event, data) {
        if (this.eventHandlers[event]) {
            this.eventHandlers[event].forEach(handler => handler(data));
        }
    }
}

export default CanvasEditor;