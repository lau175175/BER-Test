class LayerManager {
    constructor() {
        this.layers = new Map();
        this.activeLayer = null;
        this.eventHandlers = {};
        this.layerOrder = [];
    }

    init() {
        this.setupDefaultLayers();
        this.setupEventListeners();
        this.renderLayerList();
        
        // 设置默认活动层
        this.setActiveLayer('si');
    }

    setupDefaultLayers() {
        // 定义硅光工艺的默认图层
        const defaultLayers = [
            {
                id: 'si',
                name: 'Si层',
                color: '#4FC3F7',
                description: '硅波导层',
                visible: true,
                locked: false,
                opacity: 1.0,
                zIndex: 10,
                material: 'Silicon',
                thickness: 0.22, // μm
                etchDepth: 0.22
            },
            {
                id: 'sio2',
                name: 'SiO₂层',
                color: '#90A4AE',
                description: '二氧化硅包层',
                visible: true,
                locked: false,
                opacity: 0.3,
                zIndex: 5,
                material: 'Silicon Dioxide',
                thickness: 2.0
            },
            {
                id: 'metal1',
                name: 'Metal1',
                color: '#FF7043',
                description: '第一层金属',
                visible: true,
                locked: false,
                opacity: 1.0,
                zIndex: 20,
                material: 'Aluminum',
                thickness: 0.5
            },
            {
                id: 'metal2',
                name: 'Metal2',
                color: '#FF5722',
                description: '第二层金属',
                visible: true,
                locked: false,
                opacity: 1.0,
                zIndex: 25,
                material: 'Aluminum',
                thickness: 1.0
            },
            {
                id: 'via',
                name: 'Via',
                color: '#4CAF50',
                description: '金属过孔',
                visible: true,
                locked: false,
                opacity: 1.0,
                zIndex: 15,
                material: 'Tungsten',
                thickness: 0.5
            },
            {
                id: 'contact',
                name: 'Contact',
                color: '#9C27B0',
                description: '接触层',
                visible: true,
                locked: false,
                opacity: 1.0,
                zIndex: 12,
                material: 'Silicide',
                thickness: 0.1
            },
            {
                id: 'implant',
                name: 'Implant',
                color: '#FFC107',
                description: '离子注入层',
                visible: true,
                locked: false,
                opacity: 0.5,
                zIndex: 8,
                material: 'Doped Silicon',
                thickness: 0.05
            }
        ];

        // 添加图层到管理器
        defaultLayers.forEach(layer => {
            this.addLayer(layer);
        });

        // 设置图层顺序
        this.layerOrder = defaultLayers.map(layer => layer.id);
    }

    setupEventListeners() {
        // 图层可见性切换
        document.addEventListener('click', (e) => {
            if (e.target.matches('.layer-visibility')) {
                const layerItem = e.target.closest('.layer-item');
                if (layerItem) {
                    const layerId = this.getLayerIdFromElement(layerItem);
                    this.toggleLayerVisibility(layerId);
                }
            }
        });

        // 图层选择
        document.addEventListener('click', (e) => {
            if (e.target.matches('.layer-item') || e.target.closest('.layer-item')) {
                const layerItem = e.target.closest('.layer-item');
                if (layerItem && !e.target.matches('.layer-visibility') && !e.target.matches('.layer-menu')) {
                    const layerId = this.getLayerIdFromElement(layerItem);
                    this.setActiveLayer(layerId);
                }
            }
        });

        // 图层菜单
        document.addEventListener('click', (e) => {
            if (e.target.matches('.layer-menu') || e.target.closest('.layer-menu')) {
                const layerItem = e.target.closest('.layer-item');
                if (layerItem) {
                    const layerId = this.getLayerIdFromElement(layerItem);
                    this.showLayerMenu(layerId, e);
                }
                e.stopPropagation();
            }
        });

        // 添加图层按钮
        document.querySelector('.add-layer-btn')?.addEventListener('click', () => {
            this.showAddLayerDialog();
        });
    }

    getLayerIdFromElement(element) {
        // 从元素中提取图层ID（这里简化处理，实际可能需要更复杂的逻辑）
        const layers = Array.from(this.layers.keys());
        const layerItems = document.querySelectorAll('.layer-item');
        const index = Array.from(layerItems).indexOf(element);
        return this.layerOrder[index] || layers[index];
    }

    addLayer(layerData) {
        const layer = {
            id: layerData.id || this.generateLayerId(),
            name: layerData.name || 'New Layer',
            color: layerData.color || '#4FC3F7',
            description: layerData.description || '',
            visible: layerData.visible !== undefined ? layerData.visible : true,
            locked: layerData.locked || false,
            opacity: layerData.opacity || 1.0,
            zIndex: layerData.zIndex || 10,
            material: layerData.material || '',
            thickness: layerData.thickness || 0,
            etchDepth: layerData.etchDepth || 0,
            created: new Date(),
            modified: new Date()
        };

        this.layers.set(layer.id, layer);
        
        if (!this.layerOrder.includes(layer.id)) {
            this.layerOrder.push(layer.id);
        }

        this.sortLayersByZIndex();
        this.renderLayerList();
        
        this.emit('layer:added', layer);
        
        return layer;
    }

    removeLayer(layerId) {
        if (this.layers.has(layerId)) {
            const layer = this.layers.get(layerId);
            
            // 不允许删除最后一个图层
            if (this.layers.size <= 1) {
                alert('至少需要保留一个图层');
                return false;
            }

            // 如果是活动层，切换到其他层
            if (this.activeLayer === layerId) {
                const otherLayerId = Array.from(this.layers.keys()).find(id => id !== layerId);
                this.setActiveLayer(otherLayerId);
            }

            this.layers.delete(layerId);
            this.layerOrder = this.layerOrder.filter(id => id !== layerId);
            
            this.renderLayerList();
            this.emit('layer:removed', layer);
            
            return true;
        }
        return false;
    }

    getLayer(layerId) {
        return this.layers.get(layerId);
    }

    getAllLayers() {
        return Array.from(this.layers.values());
    }

    getVisibleLayers() {
        return this.getAllLayers().filter(layer => layer.visible);
    }

    setActiveLayer(layerId) {
        if (this.layers.has(layerId)) {
            this.activeLayer = layerId;
            this.renderLayerList();
            this.emit('layer:changed', this.getLayer(layerId));
        }
    }

    getActiveLayer() {
        return this.activeLayer ? this.getLayer(this.activeLayer) : null;
    }

    toggleLayerVisibility(layerId) {
        const layer = this.getLayer(layerId);
        if (layer) {
            layer.visible = !layer.visible;
            layer.modified = new Date();
            
            this.renderLayerList();
            this.emit('layer:visibility', layer, layer.visible);
        }
    }

    setLayerProperty(layerId, property, value) {
        const layer = this.getLayer(layerId);
        if (layer && layer.hasOwnProperty(property)) {
            layer[property] = value;
            layer.modified = new Date();
            
            if (property === 'zIndex') {
                this.sortLayersByZIndex();
            }
            
            this.renderLayerList();
            this.emit('layer:property:changed', layer, property, value);
        }
    }

    sortLayersByZIndex() {
        this.layerOrder.sort((a, b) => {
            const layerA = this.getLayer(a);
            const layerB = this.getLayer(b);
            return (layerB?.zIndex || 0) - (layerA?.zIndex || 0);
        });
    }

    renderLayerList() {
        const layersContainer = document.querySelector('.layers-list');
        if (!layersContainer) return;

        layersContainer.innerHTML = '';

        this.layerOrder.forEach(layerId => {
            const layer = this.getLayer(layerId);
            if (!layer) return;

            const layerElement = this.createLayerElement(layer);
            layersContainer.appendChild(layerElement);
        });
    }

    createLayerElement(layer) {
        const layerItem = document.createElement('div');
        layerItem.className = `layer-item ${layer.id === this.activeLayer ? 'active' : ''}`;
        
        layerItem.innerHTML = `
            <div class="layer-info">
                <i class="fas ${layer.visible ? 'fa-eye' : 'fa-eye-slash'} layer-visibility" 
                   style="color: ${layer.visible ? '#4fc3f7' : '#666'}"></i>
                <div class="layer-color" style="background-color: ${layer.color}; opacity: ${layer.opacity}"></div>
                <span class="layer-name" title="${layer.description}">${layer.name}</span>
                ${layer.locked ? '<i class="fas fa-lock" style="color: #ff9800; margin-left: 8px;"></i>' : ''}
            </div>
            <button class="layer-menu">
                <i class="fas fa-ellipsis-v"></i>
            </button>
        `;

        // 添加拖拽排序功能
        layerItem.draggable = true;
        layerItem.addEventListener('dragstart', (e) => {
            e.dataTransfer.setData('text/plain', layer.id);
            layerItem.classList.add('dragging');
        });

        layerItem.addEventListener('dragend', () => {
            layerItem.classList.remove('dragging');
        });

        layerItem.addEventListener('dragover', (e) => {
            e.preventDefault();
            layerItem.classList.add('drag-over');
        });

        layerItem.addEventListener('dragleave', () => {
            layerItem.classList.remove('drag-over');
        });

        layerItem.addEventListener('drop', (e) => {
            e.preventDefault();
            layerItem.classList.remove('drag-over');
            
            const draggedLayerId = e.dataTransfer.getData('text/plain');
            if (draggedLayerId !== layer.id) {
                this.reorderLayers(draggedLayerId, layer.id);
            }
        });

        return layerItem;
    }

    reorderLayers(draggedLayerId, targetLayerId) {
        const draggedIndex = this.layerOrder.indexOf(draggedLayerId);
        const targetIndex = this.layerOrder.indexOf(targetLayerId);
        
        if (draggedIndex === -1 || targetIndex === -1) return;

        // 移除被拖拽的图层
        this.layerOrder.splice(draggedIndex, 1);
        
        // 插入到目标位置
        const newTargetIndex = targetIndex > draggedIndex ? targetIndex - 1 : targetIndex;
        this.layerOrder.splice(newTargetIndex, 0, draggedLayerId);
        
        // 更新zIndex
        this.updateLayerZIndices();
        
        this.renderLayerList();
        this.emit('layers:reordered', this.layerOrder);
    }

    updateLayerZIndices() {
        this.layerOrder.forEach((layerId, index) => {
            const layer = this.getLayer(layerId);
            if (layer) {
                layer.zIndex = (this.layerOrder.length - index) * 10;
            }
        });
    }

    showLayerMenu(layerId, event) {
        const layer = this.getLayer(layerId);
        if (!layer) return;

        // 创建上下文菜单
        const menu = document.createElement('div');
        menu.className = 'layer-context-menu';
        menu.style.cssText = `
            position: fixed;
            z-index: 10000;
            background: #2a2a2a;
            border: 1px solid #404040;
            border-radius: 6px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            left: ${event.clientX}px;
            top: ${event.clientY}px;
            min-width: 150px;
        `;

        const menuItems = [
            { text: '重命名', action: () => this.renameLayer(layerId) },
            { text: '复制图层', action: () => this.duplicateLayer(layerId) },
            { text: '图层属性', action: () => this.showLayerProperties(layerId) },
            { type: 'separator' },
            { text: layer.locked ? '解锁图层' : '锁定图层', action: () => this.toggleLayerLock(layerId) },
            { type: 'separator' },
            { text: '删除图层', action: () => this.removeLayer(layerId), class: 'danger' }
        ];

        menuItems.forEach(item => {
            if (item.type === 'separator') {
                const separator = document.createElement('hr');
                separator.style.cssText = 'margin: 4px 0; border: none; border-top: 1px solid #404040;';
                menu.appendChild(separator);
            } else {
                const menuItem = document.createElement('div');
                menuItem.className = `menu-item ${item.class || ''}`;
                menuItem.style.cssText = `
                    padding: 8px 16px;
                    cursor: pointer;
                    font-size: 13px;
                    color: ${item.class === 'danger' ? '#f44336' : '#e0e0e0'};
                    transition: background-color 0.2s;
                `;
                menuItem.textContent = item.text;
                
                menuItem.addEventListener('mouseenter', () => {
                    menuItem.style.backgroundColor = item.class === 'danger' ? 'rgba(244, 67, 54, 0.1)' : 'rgba(79, 195, 247, 0.1)';
                });
                
                menuItem.addEventListener('mouseleave', () => {
                    menuItem.style.backgroundColor = 'transparent';
                });
                
                menuItem.addEventListener('click', () => {
                    item.action();
                    document.body.removeChild(menu);
                });
                
                menu.appendChild(menuItem);
            }
        });

        document.body.appendChild(menu);

        // 点击外部关闭菜单
        const closeMenu = (e) => {
            if (!menu.contains(e.target)) {
                document.body.removeChild(menu);
                document.removeEventListener('click', closeMenu);
            }
        };
        
        setTimeout(() => {
            document.addEventListener('click', closeMenu);
        }, 100);
    }

    renameLayer(layerId) {
        const layer = this.getLayer(layerId);
        if (!layer) return;

        const newName = prompt('输入新的图层名称:', layer.name);
        if (newName && newName.trim() && newName !== layer.name) {
            this.setLayerProperty(layerId, 'name', newName.trim());
        }
    }

    duplicateLayer(layerId) {
        const layer = this.getLayer(layerId);
        if (!layer) return;

        const duplicatedLayer = {
            ...layer,
            id: this.generateLayerId(),
            name: layer.name + ' 副本',
            created: new Date(),
            modified: new Date()
        };

        this.addLayer(duplicatedLayer);
    }

    toggleLayerLock(layerId) {
        const layer = this.getLayer(layerId);
        if (layer) {
            this.setLayerProperty(layerId, 'locked', !layer.locked);
        }
    }

    showLayerProperties(layerId) {
        const layer = this.getLayer(layerId);
        if (!layer) return;

        // 这里可以显示图层属性编辑对话框
        console.log('Show layer properties for:', layer);
        // 实际实现中会显示一个模态框来编辑图层属性
    }

    showAddLayerDialog() {
        // 创建添加图层对话框
        const dialog = `
            <form id="add-layer-form" style="display: flex; flex-direction: column; gap: 15px;">
                <div class="form-group">
                    <label>图层名称:</label>
                    <input type="text" id="layer-name" value="新图层" required style="margin-top: 5px;">
                </div>
                <div class="form-group">
                    <label>颜色:</label>
                    <input type="color" id="layer-color" value="#4FC3F7" style="margin-top: 5px;">
                </div>
                <div class="form-group">
                    <label>材料:</label>
                    <select id="layer-material" style="margin-top: 5px;">
                        <option value="Silicon">硅(Silicon)</option>
                        <option value="Silicon Dioxide">二氧化硅(SiO₂)</option>
                        <option value="Silicon Nitride">氮化硅(Si₃N₄)</option>
                        <option value="Aluminum">铝(Aluminum)</option>
                        <option value="Gold">金(Gold)</option>
                        <option value="Copper">铜(Copper)</option>
                        <option value="Tungsten">钨(Tungsten)</option>
                        <option value="Custom">自定义</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>厚度 (μm):</label>
                    <input type="number" id="layer-thickness" value="0.22" min="0" step="0.01" style="margin-top: 5px;">
                </div>
                <div style="display: flex; gap: 10px; margin-top: 20px;">
                    <button type="submit" style="flex: 1; padding: 10px; background: #4fc3f7; color: white; border: none; border-radius: 4px; cursor: pointer;">添加</button>
                    <button type="button" id="cancel-add-layer" style="flex: 1; padding: 10px; background: #666; color: white; border: none; border-radius: 4px; cursor: pointer;">取消</button>
                </div>
            </form>
        `;

        // 显示模态框（假设有全局的showModal函数）
        if (window.siliconDesigner && window.siliconDesigner.showModal) {
            window.siliconDesigner.showModal('添加图层', dialog);

            // 设置事件监听器
            document.getElementById('add-layer-form').addEventListener('submit', (e) => {
                e.preventDefault();
                
                const newLayer = {
                    name: document.getElementById('layer-name').value,
                    color: document.getElementById('layer-color').value,
                    material: document.getElementById('layer-material').value,
                    thickness: parseFloat(document.getElementById('layer-thickness').value),
                    zIndex: Math.max(...this.getAllLayers().map(l => l.zIndex)) + 10
                };

                this.addLayer(newLayer);
                window.siliconDesigner.closeModal();
            });

            document.getElementById('cancel-add-layer').addEventListener('click', () => {
                window.siliconDesigner.closeModal();
            });
        }
    }

    generateLayerId() {
        return 'layer_' + Math.random().toString(36).substr(2, 9);
    }

    // 导入导出
    exportLayers() {
        return {
            layers: Array.from(this.layers.entries()),
            layerOrder: this.layerOrder,
            activeLayer: this.activeLayer
        };
    }

    importLayers(data) {
        if (data.layers) {
            this.layers.clear();
            data.layers.forEach(([id, layer]) => {
                this.layers.set(id, layer);
            });
        }
        
        if (data.layerOrder) {
            this.layerOrder = data.layerOrder;
        }
        
        if (data.activeLayer) {
            this.activeLayer = data.activeLayer;
        }
        
        this.renderLayerList();
        this.emit('layers:imported', data);
    }

    // 事件系统
    on(event, handler) {
        if (!this.eventHandlers[event]) {
            this.eventHandlers[event] = [];
        }
        this.eventHandlers[event].push(handler);
    }

    emit(event, data) {
        if (this.eventHandlers[event]) {
            this.eventHandlers[event].forEach(handler => handler(data));
        }
    }
}

export default LayerManager;