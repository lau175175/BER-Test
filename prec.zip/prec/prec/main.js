
window.onload = function () {
    const canvas = document.getElementById('drawingCanvas');
    const ctx = canvas.getContext('2d');
    const clearBtn = document.getElementById('clearBtn');
    const sendBtn = document.getElementById('senBtn');

    // 调整画布大小
    function resizeCanvas() {
        canvas.width = window.innerWidth * 0.8;
        canvas.height = window.innerHeight * 0.7;
    }
    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();

    // 存储多边形的点
    let polygonPoints = [];

    // 绘制多边形
    function drawPolygon() {
        if (polygonPoints.length < 2) return; // 至少要有两个点才能形成多边形

        ctx.beginPath();
        ctx.moveTo(polygonPoints[0].x, polygonPoints[0].y); // 起始点

        // 连接所有点
        polygonPoints.forEach(point => {
            ctx.lineTo(point.x, point.y);
        });

        ctx.closePath(); // 闭合路径
        ctx.strokeStyle = '#000000'; // 黑色线条
        ctx.lineWidth = 2; // 线条宽度
        ctx.stroke(); // 绘制
    }

    // 点击画布时记录点并绘制线条
    canvas.addEventListener('click', (e) => {
        const x = e.offsetX;
        const y = e.offsetY;

        // 记录点击的点
        polygonPoints.push({ x, y });

        // 每次点击后绘制当前的多边形
        ctx.clearRect(0, 0, canvas.width, canvas.height); // 清除画布
        drawPolygon(); // 绘制已记录的多边形

        // 绘制当前点击的点
        ctx.beginPath();
        ctx.arc(x, y, 5, 0, 2 * Math.PI); // 绘制圆点
        ctx.fillStyle = 'red';
        ctx.fill();
    });

    // 双击完成多边形
    canvas.addEventListener('dblclick', () => {
        drawPolygon(); // 完成绘制
        polygonPoints = []; // 重置点数组，准备下一次绘制
    });

    // 清除画布
    clearBtn.addEventListener('click', () => {
        ctx.clearRect(0, 0, canvas.width, canvas.height); // 清空画布
        polygonPoints = []; // 清空点数组
    });

    //发送图形的JSON数据到后端
    sendBtn.addEventListener('click', () => {
        if (polygonPoints.length < 3) {
            alert("请至少绘制一个三角形或更多点的多边形！");
            return;
        }

        // 在发送数据之前将每个字典转换为 [x, y] 数组
        const convertedPoints = polygonPoints.map(point => [point.x, point.y]);

        // 将点转换为 JSON 格式发送到后端
        fetch("http://127.0.0.1:3000/api/data", { // 后端接口地址
            method: "POST", // 使用 POST 方法
            headers: {
            "Content-Type": "application/json" // 请求体类型是 JSON
            },
            body: JSON.stringify({ points: convertedPoints }) // 将图形点坐标转换为 JSON 格式
        })
        // fetch() 方法返回的是 response 对象，我们可以用 then() 方法获取数据并处理
        .then(response => response.json()) // 将response对象解析为 JSON，返回的是 Promise 对象
        .then(data => {
            // 控制台打印后端返回的数据, 并将JSON 格式的数据转换为字符串并显示在 textarea
            document.getElementById('returnData').value = "Area_Value: " + data;
        })
        .catch(error => {
            // 如果请求失败，打印错误信息
            document.getElementById("returnData").value = error;
        });

    });
}
