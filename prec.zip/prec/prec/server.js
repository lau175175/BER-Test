const express = require('express');
const path = require('path');
const os = require('os');

const app = express();
const port = 3000;

// 静态托管当前目录
app.use(express.static(path.join(__dirname)));

// 返回 index.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// 启动服务并打印局域网地址
app.listen(port, () => {
  console.log(`服务器已启动：`);
  console.log(`👉 本机访问： http://localhost:${port}`);

  // 打印局域网地址
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const net of interfaces[name]) {
      if (net.family === 'IPv4' && !net.internal) {
        console.log(`👉 局域网访问： http://${net.address}:${port}`);
      }
    }
  }
});
