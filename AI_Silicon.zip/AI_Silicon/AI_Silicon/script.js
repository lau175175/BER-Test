document.addEventListener('DOMContentLoaded', function () {
  // 获取canvas对象实例
  const canvas = new fabric.Canvas('myCanvas');

  // 设置 canvas 尺寸
  canvas.setWidth(window.innerWidth);
  canvas.setHeight(window.innerHeight);

  // 绘制网格
  function drawGrid() {
    const gridSize = 30;  // 网格大小
    const ctx = canvas.getContext('2d');
    
    ctx.save();
    ctx.setLineDash([5, 5]); // 设置虚线样式
    ctx.strokeStyle = '#D3D3D3'; // 设置颜色
    ctx.lineWidth = 0.5;

    // 绘制水平虚线
    for (let y = gridSize; y < canvas.height; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }

    // 绘制垂直虚线
    for (let x = gridSize; x < canvas.width; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }
    ctx.restore();
  }

  // 初始化网格
  drawGrid();

  // 添加一个矩形对象到 canvas
  const rect = new fabric.Rect({
    left: 100,
    top: 100,
    fill: 'blue',
    width: 150,
    height: 100
  });

  // 将矩形添加到canvas上
  canvas.add(rect);

  // 窗口大小调整时重新绘制网格
  window.addEventListener('resize', function () {
    canvas.setWidth(window.innerWidth);
    canvas.setHeight(window.innerHeight);
    drawGrid();  // 重新绘制网格
  });
});
