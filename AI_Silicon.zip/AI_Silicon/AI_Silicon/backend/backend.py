from flask import Flask, request, jsonify
from flask_cors import CORS

# 创建 Flask 应用
app = Flask(__name__)

# 启用跨域支持，允许前端访问（比如 localhost:5500 访问 localhost:5000）
CORS(app)


# 计算多边形面积的函数
def calculate_area(points):
    n = len(points)
    area = 0

    for i in range(n):
        try:
            x1, y1 = map(float, points[i])  # 确保将字符串转换为浮动数字
            x2, y2 = map(float, points[(i + 1) % n])  # 同样处理下一个点
        except ValueError as e:
            print(f"数据转换失败: {points[i]}, 错误信息: {e}")
            return None  # 如果出现错误，返回 None 或适当的错误信息
        area += x1 * y2 - x2 * y1

    return abs(area) / 2


# 定义一个 POST 接口，接收前端发送的数据
@app.route('/api/data', methods=['POST'])
def receive_data():
    # 获取 JSON 数据（前端通过 fetch 发送）
    data = request.get_json()
    points = data.get('points')  # 获取 'points' 字段的值

    # 返回一个 JSON 响应, 返回给前端。实际返回的是一个字典对象格式
    area_value = calculate_area(points)
    return jsonify(area_value)  # 返回计算的面积值

# 启动服务器
if __name__ == '__main__':
    app.run(port=3000, debug=True)
